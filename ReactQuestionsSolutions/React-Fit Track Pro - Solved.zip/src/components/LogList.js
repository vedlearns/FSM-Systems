import React from "react";
import "../App.css";

//const LogList = () => {
const LogList = ({ logs }) => {
  return (
    <div data-testid="log-list">
      <h2>Activity Log</h2>
{/*      <ul className="pl-0 ml-0 log-entry-ul">
         
        <li data-testid="log-entry" className="log-entry-li mb-10 pa-10">
          <p>
            <strong>Exercise:</strong> {`Jogging`}
          </p>
          <p>
            <strong>Duration:</strong> {`2`} minutes
          </p>
          <p>
            <strong>Calories Burned:</strong> {`100`} kcal
          </p>
        </li>
      </ul> */}
      {/* <p>No activities logged yet.</p> */}
      <ul className="pl-0 ml-0 log-entry-ul">
        {logs.map((log, idx) => (
          <li key={idx} data-testid="log-entry" className="log-entry-li mb-10 pa-10">
            {/* Tests use textContent contains "Running", "30 minutes", "300 kcal" */}
            <p><strong>Exercise:</strong> {log.exerciseType}</p>
            <p><strong>Duration:</strong> {log.duration} minutes</p>
            <p><strong>Calories Burned:</strong> {log.caloriesBurned} kcal</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default LogList;
