import React from "react";

//const LogForm = () => {
const LogForm = ({
  exerciseType,
  duration,
  caloriesBurned,
  onExerciseTypeChange,
  onDurationChange,
  onCaloriesChange,
  onLogActivity,
  onReset,
  error,
}) => {
  return (
    <div className="layout column justify-content-center align-items-center">
      <form data-testid="log-form">
        <div className="mb-10">
          <label>
            Exercise Type:
            <input
              type="text"
              name="exerciseType"
              value={exerciseType} // controlled (Test 1)
              onChange={onExerciseTypeChange}      // updates state
              //value={`Running`}     
              placeholder="e.g., Running"
              className="ml-50"
              data-testid="input-exerciseType"
              //required
            />
          </label>
        </div>
        <div className="mb-10">
          <label>
            Duration (minutes):
            <input
              type="number"
              name="duration"
              value={duration} // controlled (Test 1)
              onChange={onDurationChange}
              placeholder="e.g., 30"
              className="ml-10"
              data-testid="input-duration"
              //required
            />
          </label>
        </div>
        <div className="mb-10">
          <label>
            Calories Burned:
            <input
              type="number"
              name="caloriesBurned"
              //value={`100`}
              value={caloriesBurned}   // controlled (Test 1)
              onChange={onCaloriesChange}
              placeholder="e.g., 300"
              className="ml-30"
              data-testid="input-caloriesBurned"
              //required
            />
          </label>
        </div>
        {/* <button type="submit" data-testid="btn-logActivity" className="mr-10">
          Log Activity
        </button> */}
        <button
  type="button"
  data-testid="btn-logActivity"
  onClick={onLogActivity}
>
  Log Activity
</button>
        {/* <button type="button" data-testid="btn-resetLog">
          Reset Log
        </button> */}
        <button
  type="button"
  data-testid="btn-resetLog"
  onClick={onReset}
>
  Reset Log
</button>
      </form>
      {/* <p data-testid="error-message" style={{ color: "red" }}>
        Exercise type must not be empty.
      </p> */}
      {/* Show error only when exists (Tests 8–11) */}
      {error && (
        <p data-testid="error-message" style={{ color: "red" }}>
          {error}
        </p>
      )}
    </div>
  );
};

export default LogForm;
