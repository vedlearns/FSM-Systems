// You’re currently failing tests because your components are 
// static (hard-coded values like Running, 2, 100) and there is no state / no handlers / no validation / no log storage.
// Below is the exact step-by-step plan + exact code you should write to pass all tests (1–11).
// Step 1 — Decide where state should live (WHY)
// FitnessTracker must be the “brain” because:
// Form inputs need state (exerciseType, duration, calories)
// Logs need state (array of log entries)
// Error message needs state (string)
// So: put all state in FitnessTracker and pass it to LogForm + LogList.
// Step 2 — Make inputs “controlled” (WHY)
// Tests do:
// screen.getByTestId("input-exerciseType").value
// So inputs must have:
// value={stateValue}
// onChange={...} to update state
// Also tests expect inputs initially empty → set initial state to "".
// Step 3 — Implement Log Activity click logic (WHY)
// When button is clicked:
// Validate fields
// If invalid → show exact error message
// If valid → add a new log entry (append to logs array)
// Clear inputs after successful log (tests expect this)
// Step 4 — Implement Reset Log (WHY)
// When reset is clicked:
// Clear logs
// Clear error message (test 11 expects error removed)

//import React from "react";
import React, { useState } from "react";

import LogForm from "./LogForm";
import LogList from "./LogList";

// This is incomplete and of no use to use
// const FitnessTracker = () => {
//   return (
//     <div className="pa-20">
//       <h1>Track Your Fitness</h1>
//       <LogForm />
//       <LogList />
//     </div>
//   );
// };

const FitnessTracker = () => {
  // Inputs are empty initially (Test 1)
  const [exerciseType, setExerciseType] = useState("");
  const [duration, setDuration] = useState("");
  const [caloriesBurned, setCaloriesBurned] = useState("");

  // Logs start empty (Tests 4, 6)
  const [logs, setLogs] = useState([]);

  // Error message state (Tests 8–11)
  const [error, setError] = useState("");

  // Validation + add log (Tests 2,3,4,7,8,9,10)
  const handleLogActivity = (e) => {
    e.preventDefault(); // prevent form refresh

    // --- Validation in required order (based on tests) ---
    if (!exerciseType.trim()) {
      setError("Exercise type must not be empty.");
      return; // do not add log
    }

    // duration must be positive number (empty should fail too)
    if (!duration || Number(duration) <= 0) {
      setError("Duration must be a positive number.");
      return;
    }

    // calories must be positive number (empty should fail too)
    if (!caloriesBurned || Number(caloriesBurned) <= 0) {
      setError("Calories must be a positive number.");
      return;
    }

    // All valid → clear error
    setError("");

    // Add new log at end (order matters) (Test 3)
    const newLog = {
      exerciseType: exerciseType.trim(),
      duration: String(duration),
      caloriesBurned: String(caloriesBurned),
    };

    setLogs((prev) => [...prev, newLog]);

    // Clear inputs after success (Test 7)
    setExerciseType("");
    setDuration("");
    setCaloriesBurned("");
  };

  // Reset logs + error (Tests 5,6,11)
  const handleReset = () => {
    setLogs([]);
    setError("");
  };

  return (
    <div className="pa-20">
      <h1>Track Your Fitness</h1>

      <LogForm
        exerciseType={exerciseType}
        duration={duration}
        caloriesBurned={caloriesBurned}
        onExerciseTypeChange={(e) => setExerciseType(e.target.value)}
        onDurationChange={(e) => setDuration(e.target.value)}
        onCaloriesChange={(e) => setCaloriesBurned(e.target.value)}
        onLogActivity={handleLogActivity}
        onReset={handleReset}
        error={error}
      />

      <LogList logs={logs} />
    </div>
  );
};

export default FitnessTracker;