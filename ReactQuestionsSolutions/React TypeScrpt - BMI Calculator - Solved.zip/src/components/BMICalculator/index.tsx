import React, { useState } from 'react';
import './index.css';

type Unit = 'metric' | 'imperial';

const BMICalculator: React.FC = () => {
  const [weight, setWeight] = useState<string>('');   // ✅ string
  const [height, setHeight] = useState<string>('');   // ✅ string
  const [unit, setUnit] = useState<Unit>('metric');   // ✅ default metric
  const [bmi, setBmi] = useState<string>('-');
  const [category, setCategory] = useState<string>('-');

  const handleWeightChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setWeight(Number(val) > 0 ? val : '');
  };

  const handleHeightChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setHeight(Number(val) > 0 ? val : '');
  };

  const calculateBMI = () => {
    if (!weight || !height) {
      setBmi('-');
      setCategory('-');
      return;
    }

    const w = Number(weight);
    const h = Number(height);

    let bmiValue =
      unit === 'metric'
        ? w / Math.pow(h / 100, 2)
        : (703 * w) / Math.pow(h, 2);

    const rounded = bmiValue.toFixed(2);
    setBmi(rounded);

    const bmiNum = parseFloat(rounded);

    if (bmiNum < 18.5) setCategory('Underweight');
    else if (bmiNum <= 24.9) setCategory('Normal weight');
    else if (bmiNum <= 29.9) setCategory('Overweight');
    else setCategory('Obesity');
  };

  return (
    <div
      className="layout-column align-items-center justify-content-start bmi-calculator"
      data-testid="bmi-calculator"
    >
      <div className="bmi-calculator-scale card w-200 pt-30 pb-8 mt-20 mb-15">
        <section className="layout-row align-items-center justify-content-center mr-20 ml-20">
          <label>Weight:</label>
          <input
            type="number"
            data-testid="weight-input"
            value={weight}
            onChange={handleWeightChange}
          />
          ({unit === 'metric' ? 'kg' : 'lbs'})
        </section>

        <section className="layout-row align-items-center justify-content-center mt-20 mr-20 ml-20">
          <label>Height:</label>
          <input
            type="number"
            data-testid="height-input"
            value={height}
            onChange={handleHeightChange}
          />
          ({unit === 'metric' ? 'cm' : 'in'})
        </section>

        <section className="layout-row align-items-center justify-content-center mt-20 mr-20 ml-20">
          <label>Unit:</label>
          <select
            data-testid="unit-selector"
            value={unit}
            onChange={(e) => setUnit(e.target.value as Unit)}
          >
            <option value="metric">Metric</option>
            <option value="imperial">Imperial</option>
          </select>
        </section>

        <section className="layout-row align-items-center justify-content-center mt-20 mr-20 ml-20">
          <button data-testid="calculate-button" onClick={calculateBMI}>
            Calculate
          </button>
        </section>
      </div>

      <div className="bmi-calculator-result card w-200 mt-10 pt-10 pb-10">
        <p data-testid="bmi-result">BMI: {bmi}</p>
        <p data-testid="bmi-category">Category: {category}</p>
      </div>
    </div>
  );
};

export default BMICalculator;
