import React, {Component} from 'react';
import './App.css';
import 'h8k-components';
import ProductList from "./components/product-list";
import Cart from "./components/cart";

const title = "HackerShop";

class App extends Component {
    constructor() {
        super();
        const products = [...PRODUCTS].map((product, index) => {
            product.id = index + 1;
            product.image = `/images/items/${product.name.toLocaleLowerCase()}.png`;
            product.cartQuantity = 0;
            return product;
        });
        this.state = {
            cart: {
                items: []
            },
            products
        }
    }

    //Step 1 : First Change - this needs to be added
    updateCart = (product, mode) => {
        // Why: React state must be updated IMMUTABLY (create copies)
        const products = [...this.state.products];
        const cartItems = [...this.state.cart.items];

        // Why: product passed from child might not be same reference as in state
        // So we find the "real" product from our state copy
        const p = products.find(x => x.id === product.id);
  
        // Find if this product is already present in cart
        const cartIndex = cartItems.findIndex(ci => ci.id === p.id);

        // ---------------- ADD ----------------
        if (mode === "ADD") {
        // Increase product quantity shown in ProductList
        p.cartQuantity += 1;

        // If not in cart yet → add new row (push keeps insertion order)
        if (cartIndex === -1) {
            cartItems.push({
                id: p.id,
                item: p.name,
                quantity: 1
            });
    } else {
      // Already in cart → only increase quantity
      cartItems[cartIndex].quantity += 1;
    }
  }

  // -------------- SUBTRACT --------------
  if (mode === "SUBTRACT") {
    p.cartQuantity -= 1;

    // If quantity becomes 0 → remove from cart completely
    if (p.cartQuantity === 0) {
      cartItems.splice(cartIndex, 1);
    } else {
      // Else reduce quantity
      cartItems[cartIndex].quantity -= 1;
    }
  }

  // Why: setState triggers re-render in ProductList and Cart (sync UI)
  this.setState({
    products,
    cart: { items: cartItems }
  });
};
//Why we did it
//Keeps cart + product list always in sync
//Updates are immutable (required React best practice)
//push() preserves cart order (tests require order of adding)

    render() {
        return (
            <div>
                <h8k-navbar header={title}></h8k-navbar>
                <div className="layout-row shop-component">
                    {/* Step 2 — Pass updateCart to ProductList, In render() change your ProductList call to:*/}
                    <ProductList products={this.state.products} updateCart={this.updateCart}/>
                    {/* Why we did it: Child cannot directly change parent state. So we pass a function prop to child (React standard pattern): Props Down, Events Up*/}
                    <Cart cart={this.state.cart}/>
                </div>
            </div>
        );
    }
}

export const PRODUCTS = [
    {
        name: "Cap",
        price: 5
    },
    {
        name: "HandBag",
        price: 30
    },
    {
        name: "Shirt",
        price: 35
    },
    {
        name: "Shoe",
        price: 50
    },
    {
        name: "Pant",
        price: 35
    },
    {
        name: "Slipper",
        price: 25
    }
];
export default App;
