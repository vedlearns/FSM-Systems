import React, {Component} from "react";
import "./index.css";

export default class ProductList extends Component {
    constructor() {
        super();
    }
    //Step 3 — Use conditional rendering, Right now your ProductList shows: Add To Cart button always, Quantity controls always, But tests expect: Initially: only Add To Cart, After add: only quantity controls, What to modify, 
    // Inside render() first get props:
    render() {
        //this is the 3rd change          
        const { products, updateCart } = this.props;
        return (
            <div className="layout-row wrap justify-content-center flex-70 app-product-list">
                {this.props.products.map((product, i) => {
                    return (
                        <section className="w-30"
                                 data-testid={'product-item-' + i}
                                 key={product.id}>
                            <div className="card ma-16">
                                <img alt="Your Cart" src={product.image}
                                     className="d-inline-block align-top product-image"/>
                                <div className="card-text pa-4">
                                    <h5 className="ma-0 text-center">{product.name}</h5>
                                    <p className="ma-0 mt-8 text-center">${product.price}</p>
                                </div>
                                <div className="card-actions justify-content-center pa-4">
                                    {/* Below needs to be modified */}
                                    {/* <button className="x-small outlined" data-testid="btn-item-add">
                                        Add To Cart
                                    </button> */}
                                    {/* If item NOT in cart */}
                                    {product.cartQuantity === 0 && (<button
                                        className="x-small outlined"
                                        data-testid="btn-item-add"
                                        onClick={() => updateCart(product, "ADD")}>
                                    Add To Cart</button>)}

                                      {/* If item IS in cart, just added one updateCart function on click */}
                                      {product.cartQuantity > 0 && (
                                      
                                    <div className="layout-row justify-content-between align-items-center">
                                        <button className="x-small icon-only outlined"
                                                data-testid="btn-quantity-subtract" onClick={() => updateCart(product, "SUBTRACT")}>
                                            <i className="material-icons">remove</i>
                                        </button>

                                        <input type="number"
                                               disabled
                                               value={product.cartQuantity}
                                               className="cart-quantity" data-testid="cart-quantity"/>

                                        <button className="x-small icon-only outlined"
                                                data-testid="btn-quantity-add"
                                                onClick={() => updateCart(product, "ADD")}>
                                            <i className="material-icons">add</i>
                                        </button>
                                    </div>
                                      )}
                                </div>
                                </div>
                                </section>
                                )})}
            </div>
        );
    }
}

export const UpdateMode = {
    ADD: 1,
    SUBTRACT: 0
}
