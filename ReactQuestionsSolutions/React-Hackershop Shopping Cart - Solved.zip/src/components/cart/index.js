import React, {Component} from "react";
import "./index.css";
// Step 4 — Cart.js: No logic change (only display)
// Your Cart component is already fine.
// Why we keep it simple
// Cart is a presentational component
// It should not manage logic
// It simply displays this.props.cart.items
// This keeps code clean and matches React best practices.
// Step 5 — Expected results (to verify manually)
// Start:
// “Add To Cart” visible
// Quantity input not visible
// After Add:
// “Add To Cart” hidden
// quantity input shows 1
// and – visible
// Decrease at 1:
// row removed from cart
// “Add To Cart” comes back
// Order:
// Cart rows appear in the same order items were first added
// One key concept you should teach from this question
// Single Source of Truth + Props Down, Events Up
// App owns state
// ProductList triggers updates
// Cart only displays
export default class Cart extends Component {

    render() {
        return (
            <div className="card my-16 mr-25 flex-30">
                <section className="layout-row align-items-center justify-content-center px-16">
                    <h4>Your Cart</h4>
                </section>
                <div className="divider"/>
                <table>
                    <thead>
                    <tr>
                        <th></th>
                        <th>Item</th>
                        <th className="numeric">Quantity</th>
                    </tr>
                    </thead>
                    <tbody>
                    {
                        this.props.cart.items.map((cartItem, idx) => {
                            return (
                                <tr data-testid={'cart-item-' + idx}
                                    key={idx + 1}
                                    className="slide-up-fade-in">
                                    <td>{idx + 1}.</td>
                                    <td className="name" data-testid="cart-item-name">{cartItem.item}</td>
                                    <td className="numeric quantity" data-testid="cart-item-quantity">
                                        {cartItem.quantity}
                                    </td>
                                </tr>
                            )
                        })
                    }

                    </tbody>
                </table>
            </div>

        );
    }
}
