// import React, { useState } from "react";
// import HiddenImageDiv from "./HiddenImageDiv";

// const ImagePreview = (props) => {

//   return (
//     <div className="min-h-screen bg-background py-12">
//       <div className="container mx-auto max-w-4xl">
//         <div className="card">
//           <div className="mb-8">
//             <h1 className="text-3xl font-semibold text-center mb-2">Image Gallery</h1>
//             <p className="text-secondary text-center">Click on images to hide/show them</p>
//           </div>

//           <section className="mb-8">
//             <div
//               className="flex flex-wrap justify-center gap-4"
//               data-testid="images-div"
//             >
//               <HiddenImageDiv />
//               <HiddenImageDiv />
//             </div>
//           </section>

//           <section className="flex justify-center gap-4">
//             <button
//               className="btn btn-primary"
//               data-testid="show-all-btn"
//             >
//               Show All
//             </button>
//             <button
//               className="btn btn-secondary"
//               data-testid="hide-all-btn"
//             >
//               Hide All
//             </button>
//           </section>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default ImagePreview;

// Import React and useState hook
// React is needed for JSX
// useState is needed to manage visibility state of images
import React, { useState } from "react";

// Import the component that renders the "Hidden Image" placeholder
import HiddenImageDiv from "./HiddenImageDiv";

// Define ImagePreview component
// It receives `images` as props from App.js
const ImagePreview = (props) => {

  // -----------------------------
  // LOCAL STATE: images
  // -----------------------------
  // We clone the incoming props.images into local state
  // This is IMPORTANT because:
  // - Props must never be mutated directly
  // - Tests expect visibility toggling to work
  const [images, setImages] = useState(
    // If props.images exists, clone each object
    // Otherwise default to empty array
    props.images.map(img => ({ ...img }))
  );

  // -----------------------------
  // TOGGLE VISIBILITY OF ONE IMAGE
  // -----------------------------
  // This function is triggered when a single image tile is clicked
  const toggleImage = (index) => {
    setImages(prevImages =>
      prevImages.map((img, i) =>
        i === index
          ? { ...img, visible: !img.visible } // toggle visibility
          : img
      )
    );
  };

  // -----------------------------
  // SHOW ALL IMAGES
  // -----------------------------
  const showAll = () => {
    setImages(prevImages =>
      prevImages.map(img => ({
        ...img,
        visible: true
      }))
    );
  };

  // -----------------------------
  // HIDE ALL IMAGES
  // -----------------------------
  const hideAll = () => {
    setImages(prevImages =>
      prevImages.map(img => ({
        ...img,
        visible: false
      }))
    );
  };

  // -----------------------------
  // JSX RENDERING
  // -----------------------------
  return (
    <div className="min-h-screen bg-background py-12">
      <div className="container mx-auto max-w-4xl">
        <div className="card">

          {/* Header section */}
          <div className="mb-8">
            <h1 className="text-3xl font-semibold text-center mb-2">
              Image Gallery
            </h1>
            <p className="text-secondary text-center">
              Click on images to hide/show them
            </p>
          </div>

          {/* Images section */}
          <section className="mb-8">
            <div
              className="flex flex-wrap justify-center gap-4"
              data-testid="images-div"
            >
              {/* Render one tile per image */}
              {images.map((img, index) => (
                img.visible ? (
                  // If image is visible → show actual image
                  <img
                    key={index}
                    src={img.src}
                    alt="preview"
                    className="w-[300px] h-[200px] object-cover cursor-pointer"
                    onClick={() => toggleImage(index)}
                  />
                ) : (
                  // If image is hidden → show HiddenImageDiv
                  <HiddenImageDiv
                    key={index}
                    onClick={() => toggleImage(index)}
                  />
                )
              ))}
            </div>
          </section>

          {/* Buttons section */}
          <section className="flex justify-center gap-4">
            <button
              className="btn btn-primary"
              data-testid="show-all-btn"
              onClick={showAll}
            >
              Show All
            </button>

            <button
              className="btn btn-secondary"
              data-testid="hide-all-btn"
              onClick={hideAll}
            >
              Hide All
            </button>
          </section>

        </div>
      </div>
    </div>
  );
};

// Export component so App.js can use it
export default ImagePreview;

// I’ll do this in 3 clear parts:
// What the tests EXPECT (decoded in simple words)
// From ImagePreview.test.js, the component must do the following:
// Initial rendering
// Render one child per image inside the container with
// data-testid="images-div"
// If images array is empty → render 0 children
// If an image is visible: true → show <img src="...">
// If visible: false → show “Hidden Image”
// Click on an image
// Clicking a single image tile toggles its visibility
// Visible → Hidden
// Hidden → Visible
// Show All button
// Clicking Show All sets all images to visible
// Hide All button
// Clicking Hide All sets all images to hidden
// CRITICAL DETAIL
// The test mutates the visible property in its own copy of data:
// checkData[randomIndex].visible ^= true;
// That means your component MUST manage visibility in its own state
// You cannot rely directly on props.images.