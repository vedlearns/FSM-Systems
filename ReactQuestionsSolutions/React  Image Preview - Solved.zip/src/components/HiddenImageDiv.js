import React from "react";

const HiddenImageDiv = (props) => {
  return (
    <div 
      className="flex items-center justify-center w-[300px] h-[200px] bg-background-secondary border-2 border-dashed border-border rounded-lg cursor-pointer hover:border-border-hover hover:bg-background-tertiary transition-colors"
      {...props}
    >
      <span className="text-secondary font-medium">Hidden Image</span>
    </div>
  );
};

export default HiddenImageDiv;
