import React from "react";
import "./App.css";
import ImagePreview from "./components/ImagePreview";
import { data } from "./data";

const App = () => {
  return (
    <div className="App">
      <ImagePreview images={data} />
    </div>
  );
};

export default App;
