// import React from 'react'
// import { Ciphertext, Plaintext, Shift } from './components'
// import './App.css'
// import 'h8k-components'

// const title = "Caesar's Cipher";

// function App() {

//   return (
//     <div>
//       <h8k-navbar header={title}></h8k-navbar>
//       <Shift />
//       <div className="layout-row justify-content-center mt-40">
//         <Plaintext />
//         <Ciphertext /> 
//       </div> 
//     </div>
//   )
// }

// export default App

import React, { useCallback, useMemo, useState } from "react";
import { Ciphertext, Plaintext, Shift } from "./components";
import "./App.css";
import "h8k-components";

const title = "Caesar's Cipher";

function App() {
  // shift is kept as string because <select> values come as strings
  // later we convert to Number when doing math.
  const [shift, setShift] = useState("");          // initially "", so default option shows
  const [plainText, setPlainText] = useState("");  // value for plaintext textarea
  const [cipherText, setCipherText] = useState(""); // value for ciphertext textarea

  // ✅ encrypt function (based on your provided one, with bug fixes)
  const encryptText = useCallback((text, shiftAmount) => {
    const s = Number(shiftAmount) || 0; // convert string shift -> number
    let cipherArr = [];

    // split converts string into array of characters
    text.split("").forEach((ch) => {
      // ignore numbers & special chars except spaces:
      // - keep spaces as-is
      if (ch === " ") {
        cipherArr.push(" ");
        return;
      }

      const code = ch.charCodeAt(0); // FIX: charCodeAt expects index (0)

      // Uppercase A-Z
      if (code >= 65 && code <= 90) {
        const newCode = ((code - 65 + s) % 26) + 65;
        cipherArr.push(String.fromCharCode(newCode));
        return;
      }

      // Lowercase a-z
      if (code >= 97 && code <= 122) {
        const newCode = ((code - 97 + s) % 26) + 97;
        cipherArr.push(String.fromCharCode(newCode));
        return;
      }

      // ignore any other character (numbers/specials)
      // i.e., do nothing / skip
    });

    return cipherArr.join("");
  }, []);

  // ✅ decrypt function (based on your provided one, with bug fixes)
  const decryptText = useCallback((text, shiftAmount) => {
    const s = Number(shiftAmount) || 0;
    let plainArr = [];

    text.split("").forEach((ch) => {
      if (ch === " ") {
        plainArr.push(" ");
        return;
      }

      const code = ch.charCodeAt(0);

      // Uppercase A-Z
      if (code >= 65 && code <= 90) {
        let diff = code - 65 - s;
        if (diff < 0) diff += 26;
        plainArr.push(String.fromCharCode((diff % 26) + 65));
        return;
      }

      // Lowercase a-z
      if (code >= 97 && code <= 122) {
        let diff = code - 97 - s;
        if (diff < 0) diff += 26;
        plainArr.push(String.fromCharCode((diff % 26) + 97));
        return;
      }

      // ignore numbers/special chars
    });

    return plainArr.join("");
  }, []);

  // When user types in plaintext:
  // 1) set plaintext
  // 2) compute ciphertext based on current shift
  const handlePlainChange = (value) => {
    setPlainText(value);
    setCipherText(encryptText(value, shift));
  };

  // When user types in ciphertext:
  // 1) set ciphertext
  // 2) compute plaintext based on current shift
  const handleCipherChange = (value) => {
    setCipherText(value);
    setPlainText(decryptText(value, shift));
  };

  // When shift changes:
  // Tests always set shift before typing, but we still handle this properly.
  // If plaintext currently has data, recalc ciphertext.
  // Else if ciphertext has data, recalc plaintext.
  const handleShiftChange = (newShift) => {
    setShift(newShift);

    if (plainText !== "") {
      setCipherText(encryptText(plainText, newShift));
    } else if (cipherText !== "") {
      setPlainText(decryptText(cipherText, newShift));
    }
  };

  return (
    <div>
      <h8k-navbar header={title}></h8k-navbar>

      {/* Shift dropdown */}
      <Shift shift={shift} onShiftChange={handleShiftChange} />

      <div className="layout-row justify-content-center mt-40">
        {/* Plaintext textarea */}
        <Plaintext
          shift={shift}
          plainText={plainText}
          onPlainTextChange={handlePlainChange}
          decryptText={decryptText}
        />

        {/* Ciphertext textarea */}
        <Ciphertext cipherText={cipherText} onCipherTextChange={handleCipherChange} />
      </div>
    </div>
  );
}

export default App;
