// import React from 'react'

// function Shift() {

//   return (
//     <div className="layout-row justify-content-center mt-100">
//       <select data-testid="select">
//         <option value="" disabled>Enter shift amount</option>
//       </select>
//     </div>
//   );
// }

// export default Shift

import React from "react";

// Shift is a pure UI component.
// It receives `shift` and `onShiftChange` from parent (App).
function Shift({ shift, onShiftChange }) {
  return (
    <div className="layout-row justify-content-center mt-100">
      <select
        data-testid="select"                 // required by tests
        value={shift}                        // controlled select (React owns value)
        onChange={(e) => onShiftChange(e.target.value)} // send new shift to parent
      >
        {/* Default option: tests expect this display value initially */}
        <option value="" disabled>
          Enter shift amount
        </option>

        {/* Provide shift values. Tests use 3,5,7 so include at least 1..26 */}
        {Array.from({ length: 26 }, (_, i) => i + 1).map((n) => (
          <option key={n} value={String(n)}>
            {n}
          </option>
        ))}
      </select>
    </div>
  );
}

export default Shift;
