// Step 1 — Fix FlashCard component (render ONE card, not multiple hardcoded)
// Why?
// Right now your FlashCard:
// ignores props
// hardcodes 2 cards inside one container
// isFlipped is constant (false) so it never flips
// test expects one container per card id + proper question/answer test ids
// What to do
// Accept flashCard as prop
// Use useState for isFlipped
// On click → toggle isFlipped
// Render only that flashCard’s question + answer
// Use test ids exactly:
// flashcard-container-{id}, flashcard-question-{id}, flashcard-answer-{id}
// Replace your src/components/FlashCard/index.tsx with this:


// import React, { useState } from 'react';
// import { FlashCardProps } from '../../types/FlashCard';
// import "./index.css"

// const FlashCard: React.FC<FlashCardProps> = () => {
//   const isFlipped = false;
//   return (
//     <div
//       className="flashcard"
//       onClick={() => { }}
//       data-testid={`flashcard-container-1`}
//     >
//       <div className={`flashcard-content ${isFlipped ? 'flipped' : ''}`}>
//         <div className="front" data-testid={`flashcard-question-1`}>What is the capital of France?</div>
//         <div className="back" data-testid={`flashcard-answer-1`}>Paris</div>
//       </div>
//       <div className={`flashcard-content ${isFlipped ? 'flipped' : ''}`}>
//         <div className="front" data-testid={`flashcard-question-2`}>What is the square root of 144?</div>
//         <div className="back" data-testid={`flashcard-answer-2`}>12</div>
//       </div>
//     </div>
//   );
// };

// export default FlashCard;

//Correct Code:
import React, { useState } from "react";
import { FlashCardProps } from "../../types/FlashCard";
import "./index.css";

const FlashCard: React.FC<FlashCardProps> = ({ flashCard }) => {
  // Step 1: make isFlipped a state variable (required by spec)
  const [isFlipped, setIsFlipped] = useState(false);

  // Step 2: toggle flip on every click
  const handleFlip = () => {
    setIsFlipped((prev) => !prev);
  };

  return (
    <div
      className="flashcard"
      onClick={handleFlip}
      data-testid={`flashcard-container-${flashCard.id}`}
    >
      <div className={`flashcard-content ${isFlipped ? "flipped" : ""}`}>
        <div
          className="front"
          data-testid={`flashcard-question-${flashCard.id}`}
        >
          {flashCard.question}
        </div>

        <div className="back" data-testid={`flashcard-answer-${flashCard.id}`}>
          {flashCard.answer}
        </div>
      </div>
    </div>
  );
};

export default FlashCard;
