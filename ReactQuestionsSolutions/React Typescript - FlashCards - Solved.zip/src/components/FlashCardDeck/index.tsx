// import React from 'react';
// import { FlashCardDeckProps } from '../../types/FlashCard';
// import FlashCard from '../FlashCard';
// import "./index.css"

// const FlashCardDeck: React.FC<FlashCardDeckProps> = ({ flashCards }) => {
//   return (
//     <div className="layout-column align-items-center justify-content-start">
//       <div className="flashcard-deck" data-testid="flashcard-deck">
//         <FlashCard key={1} flashCard={flashCards[0]} />
//       </div>
//       <button onClick={() => {}} data-testid="shuffle-button">Shuffle</button>
//     </div>
//   );
// };

// export default FlashCardDeck;
//Now:
//click once → answer side (flipped class added)
//click twice → question side (flipped removed)
//ids match test expectations
//Step 2 — Fix FlashCardDeck (render ALL cards + shuffle)
//Why?
//Right now your deck:
//renders only flashCards[0]
//shuffle button does nothing
//tests expect:
//number of questions = flashCardsData.length
//shuffle changes order (not equal to original order)
//What to do
//Store cards in state: deck
//Initially set deck = props.flashCards
//Render deck.map(card => <FlashCard ... />)
//Implement shuffle so the order changes and is not same as original

import React, { useEffect, useState } from "react";
import { FlashCardDeckProps } from "../../types/FlashCard";
import FlashCard from "../FlashCard";
import "./index.css";

const FlashCardDeck: React.FC<FlashCardDeckProps> = ({ flashCards }) => {
  // Step 1: keep the deck in state so UI re-renders after shuffle
  const [deck, setDeck] = useState(flashCards);

  // Step 2: if props change, refresh deck
  useEffect(() => {
    setDeck(flashCards);
  }, [flashCards]);

  // Step 3: shuffle function (must produce different order than original)
  const shuffleDeck = () => {
    const originalOrder = flashCards.map((c) => c.id);

    let shuffled = [...deck];

    // Fisher-Yates shuffle
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }

    // Ensure order differs from original (test requirement)
    const shuffledOrder = shuffled.map((c) => c.id);
    if (shuffledOrder.join(",") === originalOrder.join(",")) {
      // simple deterministic fallback: reverse
      shuffled = [...deck].reverse();
    }

    setDeck(shuffled);
  };

  return (
    <div className="layout-column align-items-center justify-content-start">
      <div className="flashcard-deck" data-testid="flashcard-deck">
        {deck.map((card) => (
          <FlashCard key={card.id} flashCard={card} />
        ))}
      </div>

      <button onClick={shuffleDeck} data-testid="shuffle-button">
        Shuffle
      </button>
    </div>
  );
};

export default FlashCardDeck;
