// import React from "react";
// import { CirclePlus, Trash2 } from "lucide-react";

// function Tasks() {
//   return (
//     <div className="flex flex-col items-center w-full px-8">
//       <div className="w-full max-w-5xl bg-white rounded-2xl shadow p-5 mt-12 mb-8">
//         <div className="flex flex-row space-x-3 mb-6">
//           <div className="bg-[#DCFAE6] text-[#18A149] rounded-lg p-4 flex items-center justify-center">
//             <CirclePlus size={24} />
//           </div>
//           <div>
//             <div className="font-bold text-md sm:text-lg">Create a new task</div>
//             <div className="text-neutral-500 text-sm sm:text-base">
//               Add task title and priority to create a new task
//             </div>
//           </div>
//         </div>
//         <form className="flex flex-col md:flex-row gap-6 mb-3">
//           <input
//             data-testid="input-task-name"
//             className="flex-1 rounded-lg border border-gray-200 px-4 py-3 text-base focus:outline-none focus:ring-2 focus:ring-gray-800 bg-gray-100"
//             placeholder="Enter task title"
//           />
//           <input
//             data-testid="input-task-priority"
//             className="md:w-72 rounded-lg border border-gray-200 px-4 py-3 text-base focus:outline-none focus:ring-2 focus:ring-gray-800 bg-gray-100"
//             placeholder="Enter task priority"
//           />
//           <button
//             data-testid="submit-button"
//             className="h-12 px-8 rounded-md bg-black text-white font-bold text-base hover:bg-gray-900 transition"
//           >
//             Add
//           </button>
//         </form>
//       </div>

//       <div className="w-full max-w-5xl mb-6">
//         <h2 className="text-3xl font-bold text-black">Your Tasks</h2>
//       </div>
//       <div className="w-full max-w-5xl bg-white rounded-2xl shadow overflow-hidden mb-8">
//         <table className="w-full text-left">
//           <thead>
//             <tr className="border-b border-spacing-2 border-gray-200">
//               <th
//                 className="py-4 px-6 text-base font-bold text-gray-600"
//                 style={{ width: "70%" }}
//               >
//                 Task Title
//               </th>
//               <th
//                 className="py-4 px-6 text-base font-bold text-gray-600"
//                 style={{ width: "20%" }}
//               >
//                 Priority
//               </th>
//               <th className="py-4 px-6" style={{ width: "10%" }}></th>
//             </tr>
//           </thead>
//           <tbody data-testid="tasksList">
//             <tr className="border-b border-spacing-2 border-gray-200 last:border-b-0 hover:bg-gray-50 transition">
//               <td className="py-2 px-6 text-neutral-500 text-base font-normal">
//                 Schedule client meeting
//               </td>
//               <td className="py-2 px-6 text-neutral-500 text-base font-normal">
//                 01
//               </td>
//               <td className="py-2 px-6">
//                 <button className="p-2 rounded" aria-label="Delete task">
//                   <Trash2 className="w-5 h-5 text-red-500 hover:text-red-700" />
//                 </button>
//               </td>
//             </tr>
//             <tr className="border-b border-spacing-2 border-gray-200 last:border-b-0 hover:bg-gray-50 transition">
//               <td className="py-2 px-6 text-neutral-500 text-base font-normal">
//                 Update project documentation
//               </td>
//               <td className="py-2 px-6 text-neutral-500 text-base font-normal">
//                 05
//               </td>
//               <td className="py-2 px-6">
//                 <button className="p-2 rounded" aria-label="Delete task">
//                   <Trash2 className="w-5 h-5 text-red-500 hover:text-red-700" />
//                 </button>
//               </td>
//             </tr>
//           </tbody>
//         </table>
//       </div>
//     </div>
//   );
// }

// export default Tasks;

// Import React and useState hook
import React, { useState } from "react";

// Import icons
import { CirclePlus, Trash2 } from "lucide-react";

// Import toast for error notifications
import { toast } from "react-toastify";

// Create Tasks functional component
function Tasks() {

  // State to store task title input
  const [taskName, setTaskName] = useState("");

  // State to store task priority input
  const [priority, setPriority] = useState("");

  // State to store list of tasks
  const [tasks, setTasks] = useState([]);

  // Function executed when Add button is clicked
  const handleAddTask = () => {

    // Validation: if any input is empty
    if (taskName === "" || priority === "") {

      // Show toast error message (required by tests)
      toast.error("Please enter both title and task priority");
      return;
    }

    // Create new task object
    const newTask = {
      title: taskName,
      priority: Number(priority)
    };

    // Add new task and sort by priority (ascending)
    const updatedTasks = [...tasks, newTask].sort(
      (a, b) => a.priority - b.priority
    );

    // Update state with sorted tasks
    setTasks(updatedTasks);

    // Clear input fields after successful add
    setTaskName("");
    setPriority("");
  };

  // Function to delete a task by index
  const handleDelete = (indexToDelete) => {

    // Remove task at given index
    const filteredTasks = tasks.filter(
      (_, index) => index !== indexToDelete
    );

    // Update tasks state
    setTasks(filteredTasks);
  };

  // JSX UI
  return (
    <div className="flex flex-col items-center w-full px-8">

      {/* Create task card */}
      <div className="w-full max-w-5xl bg-white rounded-2xl shadow p-5 mt-12 mb-8">

        {/* Header section */}
        <div className="flex flex-row space-x-3 mb-6">
          <div className="bg-[#DCFAE6] text-[#18A149] rounded-lg p-4 flex items-center justify-center">
            <CirclePlus size={24} />
          </div>
          <div>
            <div className="font-bold text-md sm:text-lg">
              Create a new task
            </div>
            <div className="text-neutral-500 text-sm sm:text-base">
              Add task title and priority to create a new task
            </div>
          </div>
        </div>

        {/* Input form */}
        <form
          className="flex flex-col md:flex-row gap-6 mb-3"
          onSubmit={(e) => e.preventDefault()}
        >

          {/* Task name input */}
          <input
            type="text"
            data-testid="input-task-name"
            className="flex-1 rounded-lg border px-4 py-3 bg-gray-100"
            placeholder="Enter task title"
            value={taskName}
            onChange={(e) => setTaskName(e.target.value)}
          />

          {/* Priority input */}
          <input
            type="number"
            data-testid="input-task-priority"
            className="md:w-72 rounded-lg border px-4 py-3 bg-gray-100"
            placeholder="Enter task priority"
            value={priority}
            onChange={(e) => setPriority(e.target.value)}
          />

          {/* Add button */}
          <button
            type="button"
            data-testid="submit-button"
            className="h-12 px-8 rounded-md bg-black text-white font-bold"
            onClick={handleAddTask}
          >
            Add
          </button>
        </form>
      </div>

      {/* Tasks table */}
      <div className="w-full max-w-5xl bg-white rounded-2xl shadow overflow-hidden mb-8">
        <table className="w-full text-left">
          <thead>
            <tr className="border-b border-gray-200">
              <th className="py-4 px-6">Task Title</th>
              <th className="py-4 px-6">Priority</th>
              <th className="py-4 px-6"></th>
            </tr>
          </thead>

          {/* Task rows */}
          <tbody data-testid="tasksList">
            {tasks.map((task, index) => (
              <tr key={index} className="border-b border-gray-200">

                {/* Task title */}
                <td className="py-2 px-6">
                  {task.title}
                </td>

                {/* Task priority */}
                <td className="py-2 px-6">
                  {task.priority}
                </td>

                {/* Delete button */}
                <td className="py-2 px-6">
                  <button
                    onClick={() => handleDelete(index)}
                  >
                    <Trash2 className="w-5 h-5 text-red-500" />
                  </button>
                </td>

              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// Export component
export default Tasks;
