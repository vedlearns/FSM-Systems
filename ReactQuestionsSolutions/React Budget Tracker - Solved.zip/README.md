# React: Budget Balance Assistant

Build a budget tracker that allows users to manage their income and expenses.

You should be able to:
- Add an income, the total income is incremented, the balance is recomputed as total income - total expenses, and the income value is cleared.
- Add an expense, the total income is incremented, the balance is recomputed as total income - total expenses, and the income value is cleared.
- A Reset button must reset total income, total expenses, and balance to 0.00.
- Resetting should also restore the application to its initial state.

## Implementation Details
- Negative and zero inputs must not be allowed.
- Inputs for income and expense should start empty and use type number.
- Total income, total expenses, and balance should start at 0.00.

## Required Data Test IDs
The following data-testid attributes are required in the components for the test cases to pass; do not change/delete them: 

| **data-testid**      | **Description**                                   |
|-----------------------|---------------------------------------------------|
| income-input          | Input box to enter the income amount.            |
| add-income-btn        | Button to add the entered income.                |
| expense-input         | Input box to enter the expense amount.           |
| add-expense-btn       | Button to add the entered expense.               |
| total-income          | Text displaying the total income value.          |
| total-expenses        | Text displaying the total expenses value.        |
| balance               | Text displaying the current balance (income-expense). |
| reset-btn             | Button to reset the income, expense, and balance.|

## Commands

- Run:

```bash
npm start
```

- Install:

```bash
npm install
```

- Test:

```bash
npm test
```

## Read-Only Files

- `src/App.js`
- `src/App.test.js`
- `src/components/Navbar.js`
- `src/index.css`
- `src/index.js`
- `src/registerServiceWorker.js`

## Environment

- React Version: 18.2.0
- Node Version: 18(LTS)
- Default Port: 8000
