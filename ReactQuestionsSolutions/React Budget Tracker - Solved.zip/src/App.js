import React from "react";
import Navbar from "./components/Navbar";
import BudgetTracker from "./components/BudgetTracker";

const App = () => {
  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />
      <div className="max-w-6xl mx-auto px-8 py-12">
        <h1 className="text-3xl font-bold text-left mb-8">
          Track your income & expenses
        </h1>
        <BudgetTracker />
      </div>
    </div>
  );
};

export default App;
