// Import React to enable JSX and component creation
import React from "react";

// Import an icon (not required for logic, safe for UI consistency)
import { CircleMinus } from "lucide-react";

// Define the ExpenseForm functional component
// It receives props from BudgetTracker:
// 1) expenseInput     -> current value of the expense input field
// 2) setExpenseInput  -> function to update expense input state
// 3) addExpense       -> function that adds expense and clears input
const ExpenseForm = ({ expenseInput, setExpenseInput, addExpense }) => {

  // Return JSX UI
  return (

    // Use a form wrapper (semantic grouping only)
    // No submission occurs because button is type="button"
    <form>

      {/* Expense input field */}
      <input
        // Required by HackerRank tests to locate this input
        data-testid="expense-input"

        // Input must be numeric
        type="number"

        // CONTROLLED INPUT:
        // Value always comes from parent state
        value={expenseInput}

        // onChange handler:
        // Updates parent state whenever user types
        onChange={(e) => setExpenseInput(e.target.value)}
      />

      {/* Button to add expense */}
      <button
        // Required by HackerRank tests
        data-testid="add-expense-btn"

        // Prevent default form submission (page reload)
        type="button"

        // When clicked, call addExpense from parent
        onClick={addExpense}
      >
        Add
      </button>
    </form>
  );
};

// Export component so it can be used in BudgetTracker
export default ExpenseForm;
