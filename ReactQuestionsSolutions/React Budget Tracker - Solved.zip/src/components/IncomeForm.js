// import React from "react";
// import { CirclePlus } from "lucide-react";

// const IncomeForm = () => {
//   return (
//     <form className="flex-1 bg-white rounded-xl shadow p-5 flex flex-col items-start gap-6 min-w-[320px]">
//       <div className="flex flex-row space-x-3">
//         <div className="bg-[#DCFAE6] text-[#18A149] rounded-lg p-3">
//           <CirclePlus size={24} />
//         </div>
//         <div>
//           <div className="font-bold text-base">Add income</div>
//           <div className="text-neutral-500 text-sm">
//             Create an income manually
//           </div>
//         </div>
//       </div>
//       <div className="flex-1 flex w-full items-center bg-gray-100 rounded-lg border border-gray-200 px-3 py-2 mb-3">
//         <span className="text-black mr-3 text-xl">$</span>
//         <input
//           className="flex-1 bg-transparent outline-none text-black placeholder-black text-sm"
//           data-testid="income-input"
//           type="number"
//           placeholder="Enter income here"
//           value={`500`}
//         />
//         <button
//           className="ml-2 bg-black text-white px-4 py-2 rounded-lg text-sm hover:bg-gray-800 transition"
//           data-testid="add-income-btn"
//           type="button"
//         >
//           Add
//         </button>
//       </div>
//     </form>
//   );
// };

// export default IncomeForm;

// Import React so we can create a React component and write JSX (<form>...</form>)
import React from "react";

// Import CirclePlus icon from lucide-react (UI icon library)
// Note: In this minimal HackerRank solution, we are not using the icon in JSX,
// but we keep the import because your original UI used it (safe to remove if unused warnings matter).
import { CirclePlus } from "lucide-react";

// Create a functional component called IncomeForm
// It receives 3 props from the parent (BudgetTracker):
// 1) incomeInput      -> the current value shown inside the input box (controlled input)
// 2) setIncomeInput   -> function to update the incomeInput state in the parent
// 3) addIncome        -> function that runs when user clicks "Add" (adds income + clears input)
const IncomeForm = ({ incomeInput, setIncomeInput, addIncome }) => {

  // Return the JSX (UI) that should be rendered
  return (

    // Use a form tag for structure (like a typical input form)
    // Note: We do NOT submit the form (button is type="button")
    <form>

      {/* Input field for income */}
      <input
        // data-testid is REQUIRED for HackerRank tests to find this input
        data-testid="income-input"

        // type number ensures numeric input UI (and matches problem requirement)
        type="number"

        // Controlled input:
        // the displayed value is always taken from parent state (incomeInput)
        value={incomeInput}

        // onChange runs whenever user types into input
        // e.target.value gives the typed value as a string
        // we pass it to setIncomeInput to update the parent state
        onChange={(e) => setIncomeInput(e.target.value)}
      />

      {/* Button to add income */}
      <button
        // data-testid is REQUIRED for HackerRank tests to find this button
        data-testid="add-income-btn"

        // type="button" prevents default form submit behavior (page refresh)
        type="button"

        // When user clicks, call addIncome function from parent
        // Parent function will validate, update total income, and clear input
        onClick={addIncome}
      >
        {/* Button label */}
        Add
      </button>
    </form>
  );
};

// Export this component so BudgetTracker can import and use it
export default IncomeForm;

// Small Note (about the CirclePlus import)
// Right now CirclePlus is imported but not used in your minimal JSX.
// If your environment treats unused imports as warnings only, it’s fine.
// If HackerRank build fails due to ESLint “unused import”, remove this line: