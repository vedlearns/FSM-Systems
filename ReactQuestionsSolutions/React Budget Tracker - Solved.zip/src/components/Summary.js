// import React from "react";

// const Summary = () => {
//   return (
//     <div data-testid="summary" className="flex flex-col md:flex-row gap-8">
//       <div
//         data-testid="total-income"
//         className="flex-1 bg-white rounded-xl shadow p-6 min-w-[200px]"
//       >
//         <div className="text-gray-600 text-sm mb-2">Total Income</div>
//         <div className="text-4xl font-bold text-[#18A149]">$100.00</div>
//       </div>
//       <div
//         data-testid="total-expenses"
//         className="flex-1 bg-white rounded-xl shadow p-6 min-w-[200px]"
//       >
//         <div className="text-gray-600 text-sm mb-2">Total Expenses</div>
//         <div className="text-4xl font-bold text-[#D92D20]">$50.00</div>
//       </div>
//       <div
//         data-testid="balance"
//         className="flex-1 bg-white rounded-xl shadow p-6 min-w-[200px]"
//       >
//         <div className="text-gray-600 text-sm mb-2">Balance</div>
//         <div className="text-4xl font-bold text-black">$50.00</div>
//       </div>
//     </div>
//   );
// };

// export default Summary;

// Import React so we can write JSX (<div>...</div>) inside this file
import React from "react";

// Create a functional component named Summary
// It receives values from the parent component through props
// We are using object destructuring to directly extract the 3 props:
// - totalIncome: total income number
// - totalExpenses: total expenses number
// - balance: (totalIncome - totalExpenses) number

const Summary = ({ totalIncome, totalExpenses, balance }) => {
  return (
    <div>
      {/* Total Income block (tests read this exact textContent) */}
      <div data-testid="total-income">
        {/* toFixed(2) ensures strict format like 0.00 / 500.00 */}
        Total Income${totalIncome.toFixed(2)}
      </div>

      {/* Total Expenses block */}
      <div data-testid="total-expenses">
        {/* Format expenses with 2 decimals */}
        Total Expenses${totalExpenses.toFixed(2)}
      </div>

      {/* Balance block (can be negative, tests expect -200.00 etc.) */}
      <div data-testid="balance">
        {/* Format balance with 2 decimals */}
        Balance${balance.toFixed(2)}
      </div>
    </div>
  );
};

// Export Summary component so it can be imported and used in other files (like BudgetTracker.js)
export default Summary;
