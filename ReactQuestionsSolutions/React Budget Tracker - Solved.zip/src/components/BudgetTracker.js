// import React from "react";
// import IncomeForm from "./IncomeForm";
// import ExpenseForm from "./ExpenseForm";
// import Summary from "./Summary";

// const BudgetTracker = () => {
//   return (
//     <div>
//       <div className="flex flex-col md:flex-row gap-8 mb-8">
//         <IncomeForm />
//         <ExpenseForm />
//       </div>
//       <div className="flex items-center justify-between mb-8">
//         <h2 className="text-3xl font-bold text-left">Summary</h2>
//         <button
//           className="px-4 py-2 border border-neutral-300 rounded-md bg-[#FAFAFA] hover:bg-gray-100 transition font-bold text-sm"
//           data-testid="reset-btn"
//         >
//           Reset
//         </button>
//       </div>
//       <Summary />
//     </div>
//   );
// };

// export default BudgetTracker;

// Import React core library and useState hook
// React is required to create components
// useState is used to store and manage component state
import React, { useState } from "react";

// Import IncomeForm component
// This component is responsible only for income input UI
import IncomeForm from "./IncomeForm";

// Import ExpenseForm component
// This component is responsible only for expense input UI
import ExpenseForm from "./ExpenseForm";

// Import Summary component
// This component displays total income, total expenses, and balance
import Summary from "./Summary";

// Define the BudgetTracker functional component
// This is the MAIN container component that controls all state
const BudgetTracker = () => {

  // -------------------------------
  // STATE: Income input field value
  // -------------------------------
  // This state stores the value typed in the income input box
  // It MUST start as an empty string ("") according to test cases
  const [incomeInput, setIncomeInput] = useState("");

  // --------------------------------
  // STATE: Expense input field value
  // --------------------------------
  // This state stores the value typed in the expense input box
  // It MUST start as an empty string ("")
  const [expenseInput, setExpenseInput] = useState("");

  // ------------------------------
  // STATE: Total income amount
  // ------------------------------
  // This stores the cumulative total income
  // It MUST start at numeric 0
  const [totalIncome, setTotalIncome] = useState(0);

  // -------------------------------
  // STATE: Total expenses amount
  // -------------------------------
  // This stores the cumulative total expenses
  // It MUST start at numeric 0
  const [totalExpenses, setTotalExpenses] = useState(0);

  // -------------------------------
  // DERIVED STATE: Balance
  // -------------------------------
  // Balance is NOT stored separately
  // It is derived every time from income - expenses
  // This avoids state inconsistency bugs
  const balance = totalIncome - totalExpenses;

  // --------------------------------
  // FUNCTION: Add Income
  // --------------------------------
  // This function is triggered when "Add Income" button is clicked
  const addIncome = () => {

    // Convert income input (string) into a number
    const value = Number(incomeInput);

    // Validation:
    // - empty string -> Number("") = 0
    // - zero not allowed
    // - negative not allowed
    // - NaN not allowed
    if (!value || value <= 0) return;

    // Update total income using previous state
    // Using functional update avoids stale state issues
    setTotalIncome(prev => prev + value);

    // Clear the income input after successful addition
    // Required by test case #9
    setIncomeInput("");
  };

  // --------------------------------
  // FUNCTION: Add Expense
  // --------------------------------
  // This function is triggered when "Add Expense" button is clicked
  const addExpense = () => {

    // Convert expense input (string) into a number
    const value = Number(expenseInput);

    // Validation:
    // - empty string not allowed
    // - zero not allowed
    // - negative not allowed
    // - NaN not allowed
    if (!value || value <= 0) return;

    // Update total expenses using previous state
    setTotalExpenses(prev => prev + value);

    // Clear the expense input after successful addition
    // Required by test case #10
    setExpenseInput("");
  };

  // --------------------------------
  // FUNCTION: Reset All Values
  // --------------------------------
  // This function resets the entire application
  // It is triggered when Reset button is clicked
  const resetAll = () => {

    // Reset total income to 0
    setTotalIncome(0);

    // Reset total expenses to 0
    setTotalExpenses(0);

    // Reset income input back to empty string
    setIncomeInput("");

    // Reset expense input back to empty string
    setExpenseInput("");
  };

  // --------------------------------
  // JSX: Component UI Rendering
  // --------------------------------
  return (
    <div>

      {/* Section containing Income and Expense forms */}
      <div className="flex flex-col md:flex-row gap-8 mb-8">

        {/* IncomeForm component */}
        {/* Controlled component: value + setter passed from parent */}
        <IncomeForm
          incomeInput={incomeInput}
          setIncomeInput={setIncomeInput}
          addIncome={addIncome}
        />

        {/* ExpenseForm component */}
        {/* Controlled component: value + setter passed from parent */}
        <ExpenseForm
          expenseInput={expenseInput}
          setExpenseInput={setExpenseInput}
          addExpense={addExpense}
        />
      </div>

      {/* Summary header and Reset button */}
      <div className="flex items-center justify-between mb-8">

        {/* Section heading */}
        <h2 className="text-3xl font-bold text-left">Summary</h2>

        {/* Reset button */}
        {/* data-testid is REQUIRED by HackerRank tests */}
        <button
          data-testid="reset-btn"
          type="button"
          onClick={resetAll}
        >
          Reset
        </button>
      </div>

      {/* Summary component */}
      {/* Receives values via props */}
      <Summary
        totalIncome={totalIncome}
        totalExpenses={totalExpenses}
        balance={balance}
      />
    </div>
  );
};

// Export the component so it can be used in App.js
export default BudgetTracker;

// All state is lifted to the parent BudgetTracker component.
// Inputs are controlled, totals are numeric state, and balance is derived to avoid duplication.
// Validation is handled inside event handlers to ensure robustness even if buttons are clicked programmatically.
// The reset function restores the application to its initial state exactly as required by tests.”