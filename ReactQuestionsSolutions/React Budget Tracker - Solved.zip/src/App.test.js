import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import BudgetTracker from "./components/BudgetTracker";

test("1. Initially the total income, total expense, and total balance is zero", () => {
  render(<BudgetTracker />);

  expect(screen.getByTestId("total-income").textContent).toBe(
    "Total Income$0.00"
  );
  expect(screen.getByTestId("total-expenses").textContent).toBe(
    "Total Expenses$0.00"
  );
  expect(screen.getByTestId("balance").textContent).toBe("Balance$0.00");
});

test("2. Initially all the input fields are empty", () => {
  render(<BudgetTracker />);

  const incomeInput = screen.getByTestId("income-input");
  const expenseInput = screen.getByTestId("expense-input");

  expect(incomeInput.value).toBe("");
  expect(expenseInput.value).toBe("");
});

test("3. Update income and balance when income is added, total expense is unchanged", () => {
  render(<BudgetTracker />);
  const incomeInput = screen.getByTestId("income-input");
  const addIncomeBtn = screen.getByTestId("add-income-btn");

  fireEvent.change(incomeInput, { target: { value: "500" } });
  fireEvent.click(addIncomeBtn);

  expect(screen.getByTestId("total-income").textContent).toBe(
    "Total Income$500.00"
  );
  expect(screen.getByTestId("balance").textContent).toBe("Balance$500.00");
  expect(screen.getByTestId("total-expenses").textContent).toBe(
    "Total Expenses$0.00"
  );
});

test("4. Update expense and balance when expense is added, total income is unchanged", () => {
  render(<BudgetTracker />);
  const expenseInput = screen.getByTestId("expense-input");
  const addExpenseBtn = screen.getByTestId("add-expense-btn");

  fireEvent.change(expenseInput, { target: { value: "200" } });
  fireEvent.click(addExpenseBtn);

  expect(screen.getByTestId("total-expenses").textContent).toBe(
    "Total Expenses$200.00"
  );
  expect(screen.getByTestId("balance").textContent).toBe("Balance$-200.00");
  expect(screen.getByTestId("total-income").textContent).toBe(
    "Total Income$0.00"
  );
});

test("5. In existing total income, total expense, and balance, when an income is added, total income and balance values are updated, and expense is unchanged", () => {
  render(<BudgetTracker />);

  // Add initial income
  const incomeInput = screen.getByTestId("income-input");
  const addIncomeBtn = screen.getByTestId("add-income-btn");

  fireEvent.change(incomeInput, { target: { value: "500" } });
  fireEvent.click(addIncomeBtn);

  expect(screen.getByTestId("total-income").textContent).toBe(
    "Total Income$500.00"
  );
  expect(screen.getByTestId("balance").textContent).toBe("Balance$500.00");
  expect(screen.getByTestId("total-expenses").textContent).toBe(
    "Total Expenses$0.00"
  );

  // Add more income
  fireEvent.change(incomeInput, { target: { value: "300" } });
  fireEvent.click(addIncomeBtn);

  expect(screen.getByTestId("total-income").textContent).toBe(
    "Total Income$800.00"
  );
  expect(screen.getByTestId("balance").textContent).toBe("Balance$800.00");
  expect(screen.getByTestId("total-expenses").textContent).toBe(
    "Total Expenses$0.00"
  );
});

test("6. In existing total income, total expense, and balance, when an expense is added, total expense and balance values are updated, and income is unchanged", () => {
  render(<BudgetTracker />);

  // Add initial expense
  const expenseInput = screen.getByTestId("expense-input");
  const addExpenseBtn = screen.getByTestId("add-expense-btn");

  fireEvent.change(expenseInput, { target: { value: "200" } });
  fireEvent.click(addExpenseBtn);

  expect(screen.getByTestId("total-expenses").textContent).toBe(
    "Total Expenses$200.00"
  );
  expect(screen.getByTestId("balance").textContent).toBe("Balance$-200.00");
  expect(screen.getByTestId("total-income").textContent).toBe(
    "Total Income$0.00"
  );

  // Add more expense
  fireEvent.change(expenseInput, { target: { value: "100" } });
  fireEvent.click(addExpenseBtn);

  expect(screen.getByTestId("total-expenses").textContent).toBe(
    "Total Expenses$300.00"
  );
  expect(screen.getByTestId("balance").textContent).toBe("Balance$-300.00");
  expect(screen.getByTestId("total-income").textContent).toBe(
    "Total Income$0.00"
  );
});

test("7. No income or balance is updated when empty income is added", () => {
  render(<BudgetTracker />);
  const incomeInput = screen.getByTestId("income-input");
  const addIncomeBtn = screen.getByTestId("add-income-btn");

  fireEvent.change(incomeInput, { target: { value: "" } });
  fireEvent.click(addIncomeBtn);

  expect(screen.getByTestId("total-income").textContent).toBe(
    "Total Income$0.00"
  );
  expect(screen.getByTestId("balance").textContent).toBe("Balance$0.00");
});

test("8. No expense or balance is updated when empty expense is added", () => {
  render(<BudgetTracker />);
  const expenseInput = screen.getByTestId("expense-input");
  const addExpenseBtn = screen.getByTestId("add-expense-btn");

  fireEvent.change(expenseInput, { target: { value: "" } });
  fireEvent.click(addExpenseBtn);

  expect(screen.getByTestId("total-expenses").textContent).toBe(
    "Total Expenses$0.00"
  );
  expect(screen.getByTestId("balance").textContent).toBe("Balance$0.00");
});

test("9. Income field should be empty after income is added", () => {
  render(<BudgetTracker />);
  const incomeInput = screen.getByTestId("income-input");
  const addIncomeBtn = screen.getByTestId("add-income-btn");

  fireEvent.change(incomeInput, { target: { value: "500" } });
  fireEvent.click(addIncomeBtn);

  expect(incomeInput.value).toBe("");
});

test("10. Expense field should be empty after expense is added", () => {
  render(<BudgetTracker />);
  const expenseInput = screen.getByTestId("expense-input");
  const addExpenseBtn = screen.getByTestId("add-expense-btn");

  fireEvent.change(expenseInput, { target: { value: "200" } });
  fireEvent.click(addExpenseBtn);

  expect(expenseInput.value).toBe("");
});

test("11. Negative income is not added, and total income and balance remain unchanged", () => {
  render(<BudgetTracker />);

  const incomeInput = screen.getByTestId("income-input");
  const addIncomeBtn = screen.getByTestId("add-income-btn");

  // Add a negative income
  fireEvent.change(incomeInput, { target: { value: "-100" } });
  fireEvent.click(addIncomeBtn);

  // Check that total income and balance are not updated
  expect(screen.getByTestId("total-income").textContent).toBe(
    "Total Income$0.00"
  );
  expect(screen.getByTestId("balance").textContent).toBe("Balance$0.00");
});

test("12. Negative expense is not added, and total expense and balance remain unchanged", () => {
  render(<BudgetTracker />);

  const expenseInput = screen.getByTestId("expense-input");
  const addExpenseBtn = screen.getByTestId("add-expense-btn");

  // Add a negative expense
  fireEvent.change(expenseInput, { target: { value: "-50" } });
  fireEvent.click(addExpenseBtn);

  // Check that total expense and balance are not updated
  expect(screen.getByTestId("total-expenses").textContent).toBe(
    "Total Expenses$0.00"
  );
  expect(screen.getByTestId("balance").textContent).toBe("Balance$0.00");
});

test("13. Reset button sets income, expense, and balance to 0", () => {
  render(<BudgetTracker />);
  const incomeInput = screen.getByTestId("income-input");
  const addIncomeBtn = screen.getByTestId("add-income-btn");
  const resetBtn = screen.getByTestId("reset-btn");

  fireEvent.change(incomeInput, { target: { value: "300" } });
  fireEvent.click(addIncomeBtn);

  fireEvent.click(resetBtn);

  expect(screen.getByTestId("total-income").textContent).toBe(
    "Total Income$0.00"
  );
  expect(screen.getByTestId("total-expenses").textContent).toBe(
    "Total Expenses$0.00"
  );
  expect(screen.getByTestId("balance").textContent).toBe("Balance$0.00");
});
