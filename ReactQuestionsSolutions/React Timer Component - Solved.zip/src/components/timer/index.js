import React, { useEffect, useRef, useState } from "react";
import "./index.css";

export default function Timer({ initial }) {
  // 1️⃣ Timer state
  const [time, setTime] = useState(Number(initial));

  // 2️⃣ Ref to store interval id
  const intervalRef = useRef(null);

  // 3️⃣ Start timer on mount
  useEffect(() => {
    intervalRef.current = setInterval(() => {
      setTime((prev) => {
        if (prev <= 0) {
          clearInterval(intervalRef.current);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    // 4️⃣ Cleanup on unmount
    return () => clearInterval(intervalRef.current);
  }, []);

  // 5️⃣ Stop button handler
  const stopTimer = () => {
    clearInterval(intervalRef.current);
  };

  return (
    <div className="timer-container">
      <div className="timer-card">
        <div className="timer-display-wrapper">
          <div className="timer-label">Timer</div>

          {/* ✅ Timer value */}
          <div className="timer-value" data-testid="timer-value">
            {time}
          </div>

          <div className="timer-subtitle">seconds remaining</div>
        </div>

        {/* ✅ Stop Button */}
        <button
          className="btn-stop"
          data-testid="stop-button"
          onClick={stopTimer}
        >
          <svg
            className="btn-icon"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <rect
              x="6"
              y="6"
              width="12"
              height="12"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          Stop Timer
        </button>
      </div>
    </div>
  );
}
