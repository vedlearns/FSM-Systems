import React from "react";
import "./App.css";
import Timer from "./components/timer";

const App = ({initial}) => {
    return (
        <div className="App min-h-screen bg-background">
            {/* Main Content */}
            <main className="container py-12">
                <Timer initial={initial} />
            </main>
        </div>
    );
}

export default App;
