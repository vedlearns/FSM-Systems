import React from "react";
import App from "./App";
import { act } from "@testing-library/react";
import { render, fireEvent, cleanup } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";

afterEach(() => {
  cleanup();
  jest.useRealTimers();
});

let initialValue;

beforeEach(() => {
  jest.useFakeTimers();
});

test("initial UI is rendered as expected", () => {
  initialValue = 60;
  const { getByTestId } = render(<App initial={initialValue} />);
  expect(getByTestId("timer-value")).toHaveTextContent("60");
  expect(getByTestId("stop-button")).toHaveTextContent("Stop Timer");
});

test("initial value is set via props", () => {
  initialValue = 120;
  const { getByTestId } = render(<App initial={initialValue} />);

  expect(getByTestId("timer-value")).toHaveTextContent("120");

  act(() => {
    jest.advanceTimersByTime(10000); // 10 s
  });

  expect(getByTestId("timer-value")).toHaveTextContent("110");
});

test("timer stops at 0", () => {
  initialValue = 5;
  const { getByTestId } = render(<App initial={initialValue} />);

  expect(getByTestId("timer-value")).toHaveTextContent("5");

  act(() => {
    jest.advanceTimersByTime(10000); // advance well past zero
  });

  expect(getByTestId("timer-value")).toHaveTextContent("0");
});

test("stop timer button stops the timer", () => {
  initialValue = 50;
  const { getByTestId } = render(<App initial={initialValue} />);
  const stopTimerButton = getByTestId("stop-button");

  expect(getByTestId("timer-value")).toHaveTextContent("50");

  act(() => {
    jest.advanceTimersByTime(10000); // -> 40
  });

  expect(getByTestId("timer-value")).toHaveTextContent("40");

  fireEvent.click(stopTimerButton);

  act(() => {
    jest.advanceTimersByTime(10000); // should stay 40
  });

  expect(getByTestId("timer-value")).toHaveTextContent("40");
});
