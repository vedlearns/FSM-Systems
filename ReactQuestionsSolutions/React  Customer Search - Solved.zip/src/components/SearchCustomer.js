// // import React from 'react'
// // import CustomerList from './CustomerList'
// // import List from '../List';

// // function SearchCustomer() {
    
// //   return (
// //     <>
// //     <div className='layout-row align-items-center justify-content-center mt-30'>
// //         <input className='large mx-20 w-20' data-testid='search-input' value='Search' placeholder='Enter search term (Eg: Phil)' />
// //     </div>
// //     <CustomerList />
// //     </>
// //   )
// // }

// // export default SearchCustomer

// import React, { useState } from 'react';
// import CustomerList from './CustomerList';
// import customers from '../List';

// function SearchCustomer() {
//   const [searchText, setSearchText] = useState("");

//   const filteredCustomers = customers.filter(customer => {
//     if (searchText === "$") return true;

//     return (
//       customer.name.startsWith(searchText) ||
//       customer.age.toString().startsWith(searchText) ||
//       customer.location.startsWith(searchText) ||
//       customer.gender.startsWith(searchText) ||
//       customer.income.startsWith(searchText)
//     );
//   });

//   return (
//     <>
//       <div className='layout-row align-items-center justify-content-center mt-30'>
//         <input
//           type="text"
//           className='large mx-20 w-20'
//           data-testid='search-input'
//           value={searchText}
//           placeholder='Enter search term (Eg: Phil)'
//           onChange={(e) => setSearchText(e.target.value)}
//         />
//       </div>

//       <CustomerList customers={filteredCustomers} />
//     </>
//   );
// }

// export default SearchCustomer;


// 1) Imports
// import React, { useState } from 'react';
// import CustomerList from './CustomerList';
// import customers from '../List';

// React is needed because we are writing JSX (<div>...</div>).

// useState is a React Hook used to store and update UI state (here: the search text).

// CustomerList is the child component responsible for rendering the table (or “No Results”).

// customers is the original full dataset coming from List.js.

// point: “Parent component handles logic (filtering), child handles display.”

// 2) Component start + State
// function SearchCustomer() {
//   const [searchText, setSearchText] = useState("");

// SearchCustomer is a functional component.
// searchText = current input text typed by user.
// setSearchText = function to update that text.
// useState("") means initial value is empty string.

// This directly satisfies your test:
// “should initially have no input string” → must be ""

// 3) Filtering logic
//   const filteredCustomers = customers.filter(customer => {
//     if (searchText === "$") return true;

// We create a new array called filteredCustomers.
// .filter() loops through each customer.
// If the input is exactly $, we return true for every record → means “show all”.

// This satisfies test:
// “when input is dollar, display all data”

// 4) Search condition (startsWith)
//     return (
//       customer.name.startsWith(searchText) ||
//       customer.age.toString().startsWith(searchText) ||
//       customer.location.startsWith(searchText) ||
//       customer.gender.startsWith(searchText) ||
//       customer.income.startsWith(searchText)
//     );
//   });

// What is happening?

// For each customer, we check whether the search text matches the beginning of any field:

// name.startsWith(searchText)
// age.toString().startsWith(searchText)
// (because age is a number, and startsWith works only on strings)
// location.startsWith(searchText)
// gender.startsWith(searchText)
// income.startsWith(searchText)

// If any one of these is true, the customer is included in the result.

// This satisfies tests:
// “searched string should only be in the start” → startsWith
// “case-sensitive” → startsWith is case-sensitive (so "phi" won’t match "Philip")
// Also preserves order:
// .filter() keeps the same order as the original array
// → matches “same order as original data”

// 5) JSX Return (UI)
//   return (
//     <>
//       <div className='layout-row align-items-center justify-content-center mt-30'>
//         <input
//           type="text"
//           className='large mx-20 w-20'
//           data-testid='search-input'
//           value={searchText}
//           placeholder='Enter search term (Eg: Phil)'
//           onChange={(e) => setSearchText(e.target.value)}
//         />
//       </div>

//       <CustomerList customers={filteredCustomers} />
//     </>
//   );
// }

// Input element explanation

// type="text" test expects text input
// data-testid='search-input' test reads input using this
// value={searchText} makes it a controlled component
// (UI value always comes from React state)

// onChange={(e) => setSearchText(e.target.value)}
// every keystroke updates state
// component re-renders
// filter runs again
// table updates automatically

// Passing filtered data
// <CustomerList customers={filteredCustomers} />
// We send filtered results to CustomerList
// CustomerList decides:
// show table if array length > 0
// show “No Results Found!” if array length = 0

// This supports test:
// if no results → searched-customers should NOT exist, no-results should show.

// 6) Export
// export default SearchCustomer;
// Makes component usable in App.js.
// Summary:

// “SearchCustomer maintains input state, filters the master customer list using startsWith across all fields, and passes filtered results to CustomerList for rendering. Input is controlled, so the UI and state stay in sync, and filtering auto-updates on each keystroke.”

// Import React library and the useState hook (useState helps us store component state)
import React, { useState } from 'react';

// Import CustomerList component (child component responsible for displaying table / no-results)
import CustomerList from './CustomerList';

// Import the original customers array (static data source from List.js)
import customers from '../List';

// Create a functional component named SearchCustomer
function SearchCustomer() {

  // Create a state variable 'searchText' with initial value "" (empty input initially)
  // setSearchText is the function used to update the state when user types
  const [searchText, setSearchText] = useState("");

  // Create a filtered array based on current searchText
  // filter() will iterate over each customer and decide true/false to keep/remove it
  const filteredCustomers = customers.filter(customer => {

    // Special condition for the test case:
    // If user types "$", we must show all customers
    if (searchText === "$") return true;

    // Return true if the searchText matches the START of any field (startsWith)
    // OR (||) means: if any one condition is true, include this customer
    return (
      // Match if customer's name starts with searchText
      customer.name.startsWith(searchText) ||

      // Match if customer's age (converted to string) starts with searchText
      // age is a number, so we convert to string using toString()
      customer.age.toString().startsWith(searchText) ||

      // Match if customer's location starts with searchText
      customer.location.startsWith(searchText) ||

      // Match if customer's gender starts with searchText
      customer.gender.startsWith(searchText) ||

      // Match if customer's income starts with searchText
      customer.income.startsWith(searchText)
    );
  });

  // Return JSX UI for this component
  return (
    // React Fragment (<> </>) used to return multiple elements without extra wrapper div
    <>
      {/* Wrapper div to center align input box using given CSS classes */}
      <div className='layout-row align-items-center justify-content-center mt-30'>

        {/* Input box for search text */}
        <input

          // Input must be type="text" as required by unit tests
          type="text"

          // CSS classes for styling (as per boilerplate)
          className='large mx-20 w-20'

          // data-testid is required for tests to locate the input
          data-testid='search-input'

          // Controlled input: value always comes from React state
          value={searchText}

          // Placeholder text shown when input is empty
          placeholder='Enter search term (Eg: Phil)'

          // When user types, update state with new input value
          // e.target.value is what user typed
          onChange={(e) => setSearchText(e.target.value)}
        />
      </div>

      {/* Pass filtered customer list to CustomerList for rendering */}
      <CustomerList customers={filteredCustomers} />
    </>
  );
}

// Export the component so App.js can import and use it
export default SearchCustomer;
