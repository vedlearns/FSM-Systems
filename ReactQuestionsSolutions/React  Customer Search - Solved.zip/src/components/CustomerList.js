// import React from 'react'

// function CustomerList({customers}) {
//   return (
//     <div className='layout-column align-items-center justify-content-start'>
//         <p data-testid='no-results'>No Results Found!</p>
//         <div className='card w-40 pt-30 pb-8 mt-20'>
//                 <table>
//                     <thead>
//                     <tr>
//                         <th>Name</th>
//                         <th>Age</th>
//                         <th>Location</th>
//                         <th>Gender</th>
//                         <th>Income</th>
//                     </tr>
//                     </thead>
//                     <tbody data-testid='searched-customers'>
//                             <tr>
//                                 <td>Jeremy Clarke</td>
//                                 <td>21</td>
//                                 <td>Seattle</td>
//                                 <td>Male</td>
//                                 <td>$120,000</td>
//                             </tr>
//                     </tbody>
//                 </table>
//             </div>
        
//     </div>
//   )
// }

// export default CustomerList;
// Import React because we are using JSX syntax in this component
import React from 'react';

// Create a functional component named CustomerList
// It receives a prop named "customers" (an array of customer objects)
function CustomerList({ customers }) {

  // If the customers array is empty, it means no search results were found
  // In that case, we must show the "No Results Found!" message for the unit tests
  if (customers.length === 0) {

    // Return a paragraph element with required data-testid for tests
    return (
      // data-testid="no-results" is used by tests to locate this message
      <p data-testid='no-results'>No Results Found!</p>
    );
  }

  // If customers array is not empty, display the table of customers
  return (

    // Outer container div for alignment/layout using provided CSS classes
    <div className='layout-column align-items-center justify-content-start'>

      // Card container for styling and spacing (as per boilerplate CSS)
      <div className='card w-40 pt-30 pb-8 mt-20'>

        // HTML table to display customer data in rows and columns
        <table>

          // thead contains the table header section
          <thead>

            // tr represents a header row
            <tr>

              // th represents a header cell (column heading)
              <th>Name</th>

              // Header for Age column
              <th>Age</th>

              // Header for Location column
              <th>Location</th>

              // Header for Gender column
              <th>Gender</th>

              // Header for Income column
              <th>Income</th>
            </tr>
          </thead>

          // tbody contains the table body (actual data rows)
          // data-testid="searched-customers" is required by unit tests
          <tbody data-testid='searched-customers'>

            {/* Map over the customers array and render one table row per customer */}
            {customers.map((cust, index) => (

              // tr represents one customer row
              // key is required by React when rendering lists
              <tr key={index}>

                // td represents a data cell for customer name
                <td>{cust.name}</td>

                // Data cell for customer age
                <td>{cust.age}</td>

                // Data cell for customer location
                <td>{cust.location}</td>

                // Data cell for customer gender
                <td>{cust.gender}</td>

                // Data cell for customer income
                <td>{cust.income}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// Export this component so SearchCustomer (and others) can import and use it
export default CustomerList;
