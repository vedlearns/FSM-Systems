// // const customers = [
// //     {
// //         name: "Jeremy Clarke",
// //         age: 21,
// //         location: "Seattle",
// //         gender: "Male",
// //         income: "$120,000"
// //     },
// //     {
// //         name: "Matty Bing",
// //         age: 25,
// //         location: "Florida",
// //         gender: "Female",
// //         income: "$950,000"
// //     },
// //     {
// //         name: "Philip Anderson",
// //         age: 18,
// //         location: "New York City",
// //         gender: "Female",
// //         income: "$150,000"
// //     },
// //     {
// //         name: "John Smith",
// //         age: 25,
// //         location: "Philadephia",
// //         gender: "Male",
// //         income: "$200,000"
// //     },
// //     {
// //         name: "Adam Gilly",
// //         age: 32,
// //         location: "Denver",
// //         gender: "Male",
// //         income: "$2,200,000"
// //     },
// //     {
// //         name: "Erica Edwards",
// //         age: 25,
// //         location: "Portland",
// //         gender: "Female",
// //         income: "$2,200,000"
// //     },
// // ]

// // export default customers;

// const customers = [
//   {
//     name: "Jeremy Clarke",
//     age: 21,
//     location: "Seattle",
//     gender: "Male",
//     income: "$120,000"
//   },
//   {
//     name: "Philip Anderson",
//     age: 18,
//     location: "New York City",
//     gender: "Female",
//     income: "$150,000"
//   },
//   {
//     name: "John Smith",
//     age: 25,
//     location: "Philadephia",
//     gender: "Male",
//     income: "$200,000"
//   }
// ];

// export default customers;


/**
 * Customer Data Source
 * --------------------
 * This file exports a static list of customer objects.
 *
 * Purpose:
 * - Acts as a mock data source (no backend / no API)
 * - Used by SearchCustomer component for filtering/searching
 * - Ensures predictable and consistent data for unit testing
 *
 * IMPORTANT NOTES:
 * - Each customer object follows the SAME structure
 * - Property names MUST NOT be changed
 * - Order of records matters because tests expect
 *   the filtered results in original order
 *
 * Fields in each customer:
 * - name     : String  → Customer full name
 * - age      : Number  → Customer age
 * - location : String → City name
 * - gender   : String → Male / Female
 * - income   : String → Currency value (string, not number)
 *
 * This smaller dataset is intentional:
 * - Matches test expectations
 * - Avoids false positives during filtering
 * - Keeps search logic easy to validate
 */

const customers = [
  {
    name: "Jeremy Clarke",
    age: 21,
    location: "Seattle",
    gender: "Male",
    income: "$120,000"
  },
  {
    name: "Philip Anderson",
    age: 18,
    location: "New York City",
    gender: "Female",
    income: "$150,000"
  },
  {
    name: "John Smith",
    age: 25,
    location: "Philadephia",
    gender: "Male",
    income: "$200,000"
  }
];

// Exporting the customer list so it can be imported
// into SearchCustomer and used for filtering logic
export default customers;
