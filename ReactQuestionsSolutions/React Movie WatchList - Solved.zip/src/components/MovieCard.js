// import React from "react";

// const MovieCard = () => {
//   return (
//     // set all data-testids according to the movie id.
//     // Ex: on the movie card the data-testid for movie with id:1  will be movie-card-1
//     <div className="movie-card" data-testid={`movie-card-0`}>
//       <h3 data-testid={`movie-title-0`}>{`Inception`}</h3>
//       <button className="danger" data-testid={`remove-btn-0`}>
//         Remove
//       </button>
//       <button data-testid={`add-btn-0`}>
//         {/* "Added" */}
//         Add to Watchlist
//       </button>
//     </div>
//   );
// };

// export default MovieCard;


import React from "react"; // React needed for JSX

// MovieCard is reusable for both sections:
// - Movies list (Add button active, Remove disabled until added)
// - Watchlist (Remove button active, Add button hidden)
const MovieCard = ({
  movie, // {id, title}
  isAdded, // boolean -> whether movie is in watchlist
  onAdd, // function to add movie to watchlist
  onRemove, // function to remove movie from watchlist
  showAddButton = true, // when false, we hide add button (for watchlist section)
}) => {
  // id is used to create data-testid values required by tests
  const { id, title } = movie;

  return (
    // set data-testid according to movie id (movie-card-1, movie-card-2, ...)
    <div className="movie-card" data-testid={`movie-card-${id}`}>
      {/* movie title test id must include the id */}
      <h3 data-testid={`movie-title-${id}`}>{title}</h3>

      {/* Remove button:
          - enabled only if already added
          - disabled if not added (in Movies list) */}
      {/* REMOVE button → ONLY in Watchlist */}
      {!showAddButton && (
        <button
          className="danger"
          data-testid={`remove-btn-${id}`}
          onClick={() => onRemove(id)}
        >
          Remove
        </button>
      )}

      {/* ADD button → ONLY in Movies */}
      {showAddButton && (
        <button
          data-testid={`add-btn-${id}`}
          disabled={isAdded}
          onClick={() => onAdd(id)}
        >
          {isAdded ? "Added" : "Add to Watchlist"}
        </button>
      )}
    </div>
  );
};

export default MovieCard; // export for reuse
