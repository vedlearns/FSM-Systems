// import React from "react";
// import MovieCard from "./MovieCard";
// import Watchlist from "./Watchlist";

// const movies = [
//   { id: 1, title: "Inception" },
//   { id: 2, title: "Interstellar" },
//   { id: 3, title: "The Dark Knight" },
//   { id: 4, title: "Dunkirk" },
//   { id: 5, title: "The Shawshank Redemption" },
// ];

// const WatchlistApp = () => {
//   return (
//     <div>
//       <h2>Movies</h2>
//       <div className="movies-container">
//         <MovieCard />
//       </div>

//       <Watchlist />
//     </div>
//   );
// };

// export default WatchlistApp;


import React, { useMemo, useState } from "react"; // useState: store watchlist state, useMemo: derive data efficiently
import MovieCard from "./MovieCard"; // reusable card for both Movies and Watchlist sections
import Watchlist from "./Watchlist"; // watchlist section component

// Read-only input list of all movies available in the app
const movies = [
  { id: 1, title: "Inception" },
  { id: 2, title: "Interstellar" },
  { id: 3, title: "The Dark Knight" },
  { id: 4, title: "Dunkirk" },
  { id: 5, title: "The Shawshank Redemption" },
];

const WatchlistApp = () => {
  // watchlistIds stores ONLY the ids of movies added to watchlist (e.g., [1, 3, 5])
  // We store ids (not full objects) because it is simpler and avoids duplication.
  const [watchlistIds, setWatchlistIds] = useState([]); // initially empty watchlist

  // Helper: check if a movie is already in watchlist
  // We keep it as a function so both render sections can reuse it.
  const isWatchlisted = (movieId) => watchlistIds.includes(movieId);

  // Add handler: adds movieId if not already present
  const addToWatchlist = (movieId) => {
    // If already present, do nothing (prevents duplicates)
    if (watchlistIds.includes(movieId)) return;

    // Create a NEW array (immutability) so React re-renders
    setWatchlistIds([...watchlistIds, movieId]);
  };

  // Remove handler: removes movieId if present
  const removeFromWatchlist = (movieId) => {
    // Filter returns a new array without the removed id
    setWatchlistIds(watchlistIds.filter((id) => id !== movieId));
  };

  // Clear handler: clears all items from watchlist
  const clearWatchlist = () => {
    setWatchlistIds([]); // set to empty array
  };

  // Derived data: list of actual movie objects in watchlist
  // We use useMemo so it recalculates only when watchlistIds changes.
  const watchlistedMovies = useMemo(() => {
    // Convert ids → actual movie objects from movies array
    return movies.filter((m) => watchlistIds.includes(m.id));
  }, [watchlistIds]);

  return (
    <div>
      {/* Movies section */}
      <h2>Movies</h2>

      {/* movies-container is used by the UI layout and tests typically */}
      <div className="movies-container">
        {/* Render ALL movies */}
        {movies.map((movie) => (
          <MovieCard
            key={movie.id} // React list key to track items efficiently
            movie={movie} // pass movie data (id + title)
            isAdded={isWatchlisted(movie.id)} // tells card if already in watchlist
            onAdd={addToWatchlist} // callback to add
            onRemove={removeFromWatchlist} // callback to remove
            showAddButton={true} // in Movies list we show add button
          />
        ))}
      </div>

      {/* Watchlist section */}
      <Watchlist
        watchlistedMovies={watchlistedMovies} // actual movie objects in watchlist
        onRemove={removeFromWatchlist} // removing from watchlist
        onClear={clearWatchlist} // clear all
      />
    </div>
  );
};

export default WatchlistApp; // export so App.js can render it
