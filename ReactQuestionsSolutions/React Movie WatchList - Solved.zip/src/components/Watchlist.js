// import React from "react";
// import MovieCard from "./MovieCard";

// const Watchlist = () => {
//   return (
//     <div data-testid="watchlist-container">
//       {/* Provide the total count of movies watchlisted */}
//       <h2>Watchlist {<span>(1)</span>}</h2>
//       {/* <p data-testid="watchlist-empty">Your watchlist is empty.</p> */}
//       <div>
//         <div data-testid="movie-container" className="movies-container">
//           <MovieCard />
//         </div>
//         <button data-testid="clear-watchlist-btn">Clear Watchlist</button>
//       </div>
//     </div>
//   );
// };

// export default Watchlist;

import React from "react"; // React needed for JSX
import MovieCard from "./MovieCard"; // reuse card to show watchlisted movies

const Watchlist = ({ watchlistedMovies, onRemove, onClear }) => {
  // Count is used in heading: Watchlist (n)
  const count = watchlistedMovies.length;

  return (
    // data-testid used by unit tests to locate the watchlist container
    <div data-testid="watchlist-container">
      {/* Provide the total count of movies watchlisted */}
      <h2>
        Watchlist <span>({count})</span>
      </h2>

      {/* If empty, show empty message (tests often expect this) */}
      {count === 0 ? (
        <p data-testid="watchlist-empty">Your watchlist is empty.</p>
      ) : (
        <div>
          {/* Container for movies in watchlist (tests often search this) */}
          <div data-testid="movie-container" className="movies-container">
            {watchlistedMovies.map((movie) => (
              <MovieCard
                key={movie.id} // React key for lists
                movie={movie} // pass movie data
                isAdded={true} // in watchlist it is obviously added
                onAdd={() => {}} // not used here because we hide add button
                onRemove={onRemove} // removing is required in watchlist
                showAddButton={false} // hide add button in watchlist section
              />
            ))}
          </div>

          {/* Clear watchlist button */}
          <button data-testid="clear-watchlist-btn" onClick={onClear}>
            Clear Watchlist
          </button>
        </div>
      )}
    </div>
  );
};

export default Watchlist; // export for WatchlistApp
