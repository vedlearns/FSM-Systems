import React, { Component } from "react";
import "./index.css";

export default class KanbanBoard extends Component {
  constructor(props) {
    super(props);

    this.state = {
      tasks: props.tasks
    };

    this.stagesNames = ["Backlog", "To Do", "Ongoing", "Done"];
  }

  moveTask = (taskName, direction) => {
    this.setState((prevState) => ({
      tasks: prevState.tasks.map((task) => {
        if (task.name !== taskName) return task;

        const newStage = task.stage + direction;

        if (newStage < 0 || newStage > 3) return task;

        return {
          ...task,
          stage: newStage
        };
      })
    }));
  };

  render() {
    const { tasks } = this.state;

    const stagesTasks = Array.from({ length: 4 }, () => []);

    tasks.forEach((task) => {
      stagesTasks[task.stage].push(task);
    });

    return (
      <div className="mt-20 layout-column justify-content-center align-items-center">
        <div className="mt-50 layout-row">
          {stagesTasks.map((stageTasks, stageIndex) => (
            <div className="card outlined ml-20 mt-0" key={stageIndex}>
              <div className="card-text">
                <h4>{this.stagesNames[stageIndex]}</h4>

                <ul
                  className="styled mt-50"
                  data-testid={`stage-${stageIndex}`}
                >
                  {stageTasks.map((task) => {
                    const taskKey = task.name.split(" ").join("-");

                    return (
                      <li className="slide-up-fade-in" key={task.name}>
                        <div className="li-content layout-row justify-content-between align-items-center">
                          <span data-testid={`${taskKey}-name`}>
                            {task.name}
                          </span>

                          <div className="icons">
                            <button
                              className="icon-only x-small mx-2"
                              data-testid={`${taskKey}-back`}
                              disabled={task.stage === 0}
                              onClick={() =>
                                this.moveTask(task.name, -1)
                              }
                            >
                              <i className="material-icons">arrow_back</i>
                            </button>

                            <button
                              className="icon-only x-small mx-2"
                              data-testid={`${taskKey}-forward`}
                              disabled={task.stage === 3}
                              onClick={() =>
                                this.moveTask(task.name, 1)
                              }
                            >
                              <i className="material-icons">
                                arrow_forward
                              </i>
                            </button>
                          </div>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }
}


// Never use array index for state mutation in UI tests
// Always use domain keys (here → task.name)