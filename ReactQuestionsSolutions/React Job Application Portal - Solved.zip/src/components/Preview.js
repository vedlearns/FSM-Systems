// import React from "react";

// const Preview = () => {
//   return (
//     <div data-testid="preview">
//       <h2>Preview Your Application</h2>
//       <p data-testid="preview-name">
//         <strong>Name:</strong> {`User`}
//       </p>
//       <p data-testid="preview-email">
//         <strong>Email:</strong> {`user@ymail.com`}
//       </p>
//       <p data-testid="preview-experience">
//         <strong>Experience:</strong> {`3`} years
//       </p>
//       <button data-testid="clear-button">Clear</button>
//       <button data-testid="submit-button">Submit</button>
//     </div>
//   );
// };

// export default Preview;

import React from "react";

const Preview = ({ name, email, experience, onClear, onSubmit }) => {
  return (
    <div data-testid="preview">

      <h2>Preview Your Application</h2>

      <p data-testid="preview-name">Name: {name}</p>
      <p data-testid="preview-email">Email: {email}</p>
      <p data-testid="preview-experience">
        Experience: {experience} years
      </p>

      <button data-testid="clear-button" onClick={onClear}>
        Clear
      </button>

      <button data-testid="submit-button" onClick={onSubmit}>
        Submit
      </button>
    </div>
  );
};

export default Preview;
