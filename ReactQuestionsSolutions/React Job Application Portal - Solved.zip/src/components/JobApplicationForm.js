// import React from "react";

// const JobApplicationForm = () => {
//   return (
//     <form data-testid="job-application-form" className="layout-column ml-auto">
//       <h2 className="ma-auto pa-20">Provide your details</h2>
//       <div>
//         <label className="font-weight-bold">
//           Name:
//           <input
//             data-testid="input-name"
//             type="text"
//             name="name"
//             value={`User`}
//             className="pa-10 ml-120"
//           />
//         </label>
//         <p data-testid="error-name" className="error">
//           Error message for Name.
//         </p>
//       </div>
//       <div>
//         <label className="font-weight-bold">
//           Email:
//           <input
//             data-testid="input-email"
//             type="email"
//             name="email"
//             value={`user@ymail.com`}
//             className="pa-10 ml-120"
//           />
//         </label>
//         <p data-testid="error-email" className="error">
//           Error message for email address.
//         </p>
//       </div>
//       <div>
//         <label className="font-weight-bold">
//           Experience (years):
//           <input
//             data-testid="input-experience"
//             type="text"
//             name="experience"
//             value={`3`}
//             className="pa-10 ml-20"
//           />
//         </label>
//         <p data-testid="error-experience" className="error">
//           Error message for Experience.
//         </p>
//       </div>
//       <div className="ml-100">
//         <button data-testid="preview-button" type="submit" className="mx-50">
//           Preview
//         </button>
//         <button data-testid="reset-button" type="button" className="mx-50">
//           Reset
//         </button>
//       </div>
//     </form>
//   );
// };

// export default JobApplicationForm;


import React from "react";

const JobApplicationForm = ({
  name,
  email,
  experience,
  setName,
  setEmail,
  setExperience,
  errors,
  onPreview,
  onReset,
}) => {
  return (
    <form data-testid="job-application-form">

      <h2>Provide your details</h2>

      <div>
        <label>
          Name:
          <input
            data-testid="input-name"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </label>
        {errors.name && (
          <p data-testid="error-name">{errors.name}</p>
        )}
      </div>

      <div>
        <label>
          Email:
          <input
            data-testid="input-email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </label>
        {errors.email && (
          <p data-testid="error-email">{errors.email}</p>
        )}
      </div>

      <div>
        <label>
          Experience (years):
          <input
            data-testid="input-experience"
            type="text"
            value={experience}
            onChange={(e) => setExperience(e.target.value)}
          />
        </label>
        {errors.experience && (
          <p data-testid="error-experience">{errors.experience}</p>
        )}
      </div>

      <button
        data-testid="preview-button"
        type="button"
        onClick={onPreview}
      >
        Preview
      </button>

      <button
        data-testid="reset-button"
        type="button"
        onClick={onReset}
      >
        Reset
      </button>
    </form>
  );
};

export default JobApplicationForm;
