// import React from "react";

// const SuccessMessage = () => {
//   return (
//     <div data-testid="success-message">
//       <h2>Application Submitted Successfully!</h2>
//       <p>Thank you for your application. We will review it soon.</p>
//       <button className="ma-auto" data-testid="reset-button">
//         Home
//       </button>
//     </div>
//   );
// };

// export default SuccessMessage;

import React from "react";

const SuccessMessage = ({ onHome }) => {
  return (
    <div data-testid="success-message">
      <h2>Application Submitted Successfully!</h2>
      <p>Thank you for your application. We will review it soon.</p>

      <button data-testid="reset-button" onClick={onHome}>
        Home
      </button>
    </div>
  );
};

export default SuccessMessage;

// I’ll do this in four clear steps:
// STEP 1: What the tests EXPECT (very important)
// From App.test.js, the app must behave like this:
// Screens (mutually exclusive)
// Form screen (default)
// Preview screen
// Success screen
// Only ONE should be visible at a time.
// State requirements
// Inputs must be controlled
// Inputs must start empty
// Validation errors must:
// Show only after clicking Preview
// Disappear on reset
// Email must match a valid pattern
// Experience must be a positive number
// Buttons behavior
// Button	Action
// Preview	Validate → if valid, show Preview
// Reset (form)	Clear inputs + errors
// Clear (preview)	Go back to form + clear data
// Submit (preview)	Show success
// Home (success)	Go back to form + clear data
// STEP 2: State ownership (DESIGN DECISION)
// ALL state must live in App.js
// Why?
// App decides which screen to show
// Children are pure UI components
// This is exactly what HackerRank expects.
// STEP 3: FINAL SOLUTION (ALL FILES)