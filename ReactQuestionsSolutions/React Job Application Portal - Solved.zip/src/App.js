// import React from "react";
// import "./App.css";
// import "h8k-components";
// import JobApplicationForm from "./components/JobApplicationForm";
// import Preview from "./components/Preview";
// import SuccessMessage from "./components/SuccessMessage";

// const title = "Job Application Portal";

// const App = () => {
//   return (
//     <div className="App pt-30 ma-auto" data-testid="app">
//       <h8k-navbar header={title}></h8k-navbar>
//       <JobApplicationForm />
//       {/* <Preview />
//       <SuccessMessage /> */}
//     </div>
//   );
// };

// export default App;

// Import React and useState hook
import React, { useState } from "react";

// Import styles
import "./App.css";

// Import HackerRank UI component
import "h8k-components";

// Import child components
import JobApplicationForm from "./components/JobApplicationForm";
import Preview from "./components/Preview";
import SuccessMessage from "./components/SuccessMessage";

// Title shown in navbar
const title = "Job Application Portal";

const App = () => {

  // -------------------------
  // FORM DATA STATE
  // -------------------------
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [experience, setExperience] = useState("");

  // -------------------------
  // ERROR STATE
  // -------------------------
  const [errors, setErrors] = useState({});

  // -------------------------
  // SCREEN STATE
  // form | preview | success
  // -------------------------
  const [screen, setScreen] = useState("form");

  // -------------------------
  // VALIDATION FUNCTION
  // -------------------------
  const validate = () => {
    const newErrors = {};

    if (!name.trim()) {
      newErrors.name = "Name is required.";
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      newErrors.email = "Enter a valid email address.";
    }

    if (!experience || Number(experience) <= 0) {
      newErrors.experience = "Experience must be a positive number.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // -------------------------
  // PREVIEW HANDLER
  // -------------------------
  const handlePreview = () => {
    if (validate()) {
      setScreen("preview");
    }
  };

  // -------------------------
  // RESET ALL STATE
  // -------------------------
  const resetAll = () => {
    setName("");
    setEmail("");
    setExperience("");
    setErrors({});
    setScreen("form");
  };

  return (
    <div className="App pt-30 ma-auto" data-testid="app">
      <h8k-navbar header={title}></h8k-navbar>

      {/* FORM SCREEN */}
      {screen === "form" && (
        <JobApplicationForm
          name={name}
          email={email}
          experience={experience}
          setName={setName}
          setEmail={setEmail}
          setExperience={setExperience}
          errors={errors}
          onPreview={handlePreview}
          onReset={resetAll}
        />
      )}

      {/* PREVIEW SCREEN */}
      {screen === "preview" && (
        <Preview
          name={name}
          email={email}
          experience={experience}
          onClear={resetAll}
          onSubmit={() => setScreen("success")}
        />
      )}

      {/* SUCCESS SCREEN */}
      {screen === "success" && (
        <SuccessMessage onHome={resetAll} />
      )}
    </div>
  );
};

export default App;
