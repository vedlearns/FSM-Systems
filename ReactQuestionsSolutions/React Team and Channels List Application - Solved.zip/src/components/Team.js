// You’re currently rendering UI, but nothing is wired: input has no state
// buttons are never disabled/enabled correctly, clicking Add doesn’t add anything
// delete doesn’t remove anything, IDs for new channels are not generated
// So we’ll do this in the correct React way:

// TeamList owns the “teams” state (because teams list changes)
// Team owns only its input state (channel input text)
// Team calls parent callbacks to actually update teams

// Step 1: TeamList will store teams in state
// Why? Because adding team, adding channel, removing channel all change teams array.
// Step 2: Controlled input for team name + disable button logic
// Why?
// Tests expect “Add Team” disabled initially
// Enabled only when name is: // not empty after trim // unique (not already present)
// Step 3: Pass callbacks to Team component
// Why? // Team cannot directly modify teams state (it doesn’t own it).
// So Team will call:
// onAddChannel(teamIndex, channelName)
// onRemoveChannel(teamIndex, channelId)

// Step 4: In Team, implement controlled channel input + disable button logic
// Why?
// “Add Channel” disabled initially // enabled only when name is:
// not empty after trim // unique inside that team

// Step 5: Generate incremental channel id
// Why? Tests require unique incremental ID.
// We will compute:
// nextId = (max existing id) + 1
// if no channels → id = 0

// FIX 1: 

// “Add Team” / “Add Channel” button must start disabled
// If you don’t set disabled={...}, unit tests fail immediately.
// Uniqueness matters // Tests check you can’t add the same:
// team twice
// channel twice in same team
// Channel ID must be incremental

// If you always use id: channels.length, deleting breaks uniqueness.
// So we used (maxId + 1).
// Quick check (what you should see)

// Add Team disabled initially
// Type unique name → enabled
// Add team appears in list
// Each team has Add Channel disabled initially
// Type unique channel name → enabled
// Delete removes it
// TestIDs remain exactly as required

// import React from 'react'

// import './Team.css'

// const Team = ({ team, id }) => {

//   return (
//     <div>
//       {
//         team && <h4 className='mt-0 mb-6' >{ team.name }</h4>
//       }
//       {
//         team &&
//         <div className='layout-row justify-content-end mb-6'>
//           <input 
//             placeholder='Enter Channel Name'
//             className="channel-name-input w-45 px-13"
//             data-testid={ 'channel-name-input-' + id }
//           />
//           <button 
//             className='channel-name-btn x-small w-35 h-30 pa-6 ma-0 ml-6'
//             data-testid={ 'add-channel-btn-' + id }
//           >
//             Add Channel
//           </button>
//         </div>
//       }
//       {
//         team &&
//         <ul className='styled mb-20 pl-25' data-testid={ 'channel-list-' + id }>
//           { team.channels && team.channels.map((channel) => (
//             <li 
//               key={ channel.id } 
//               className='flex slide-up-fade-in justify-content-between align-items-center pl-10 pr-5 py-6 mt-0 mb-6'
//             >
//               <span>{ channel.name }</span>
//               <button 
//                 data-testid={ 'remove-channel-button-' + id + channel.id }
//                 className='icon-only x-small danger ma-0 pa-0'
//               >
//                 <i className="material-icons">delete</i>
//               </button>
//             </li>
//           ))}
//         </ul>
//       }  
//     </div>
    
//   )
// }

// export default Team

import React, { useMemo, useState } from "react";

const Team = ({ team, teamIndex, onAddChannel, onRemoveChannel }) => {
  const [channelName, setChannelName] = useState("");

  const normalizedChannel = channelName.trim().toLowerCase();

  const existingChannels = useMemo(
    () => new Set(team.channels.map((c) => c.toLowerCase())),
    [team.channels]
  );

  const canAddChannel =
    normalizedChannel.length > 0 &&
    !existingChannels.has(normalizedChannel);

  const handleAdd = () => {
    if (!canAddChannel) return;
    onAddChannel(teamIndex, channelName.trim());
    setChannelName("");
  };

  return (
    <div>
      <h4 className="mt-0 mb-6">{team.name}</h4>

      <div className="layout-row justify-content-end mb-6">
        <input
          className="channel-name-input w-45 px-13"
          placeholder="Enter Channel Name"
          data-testid={`channel-name-input-${teamIndex}`}
          value={channelName}
          onChange={(e) => setChannelName(e.target.value)}
        />

        <button
          type="button"
          className="channel-name-btn x-small w-35 h-30 pa-6 ma-0 ml-6"
          data-testid={`add-channel-btn-${teamIndex}`}
          disabled={!canAddChannel}
          onClick={handleAdd}
        >
          Add Channel
        </button>
      </div>

      <ul
        className="styled mb-20 pl-25"
        data-testid={`channel-list-${teamIndex}`}
      >
        {team.channels.map((channel, channelIndex) => (
          <li
            key={`${channel}-${channelIndex}`}
            className="flex slide-up-fade-in justify-content-between align-items-center pl-10 pr-5 py-6 mt-0 mb-6"
          >
            <span>{channel}</span>
            <button
              type="button"
              className="icon-only x-small danger ma-0 pa-0"
              data-testid={`remove-channel-button-${teamIndex}${channelIndex + 1}`}
              onClick={() => onRemoveChannel(teamIndex, channelIndex)}
            >
              delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Team;
