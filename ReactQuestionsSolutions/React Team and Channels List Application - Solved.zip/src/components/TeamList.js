// import React, { useState } from 'react'
// import Team from './Team'

// import './TeamList.css'

// const TeamList = () => {
//   const teamList = [
//     { name: 'Team1',
//       channels: [
//         { name: 'Channel1',
//           id: 1
//         },
//         { name: 'Channel2',
//           id: 2
//         }
//       ]
//     },
//     { name: 'Team2',
//       channels: [
//         { name: 'Channel1',
//           id: 1
//         },
//         { name: 'Channel2',
//           id: 2
//         }
//       ]
//     }
//   ]

//   return (
//     <div className='w-50 mx-auto'>
//       <div className='card w-35 mt-50 mx-auto px-10 py-15'>
//         <div className='layout-column' data-testid='team-list'>
//           { teamList && teamList.map((team, id) => (
//             <Team
//               key={ id } 
//               id={ id }
//               team={ team } 
//             />
//           ))}
//         </div>
//         <div className='layout-row'>
//           <input 
//             placeholder='Enter Team Name'
//             className='team-list-input w-75'
//             data-testid='team-name-input'
//           />
//           <button 
//             className='team-list-btn x-small w-35 h-30 pa-6 ma-0 ml-6'
//             data-testid='add-team-btn'
//           >
//             Add Team
//           </button>
//         </div> 
//       </div>
//     </div>
//   )
// }

// export default TeamList

// FIX 2:
import React, { useMemo, useState } from "react";
import Team from "./Team";

/**
 * EXACT initial data expected by tests
 */
const initialTeams = [
  { name: "Team1", channels: ["Channel1", "Channel2"] },
  { name: "Team2", channels: ["Channel1", "Channel2"] }
];

const TeamList = () => {
  const [teams, setTeams] = useState(initialTeams);
  const [teamName, setTeamName] = useState("");

  const normalizedTeamInput = teamName.trim().toLowerCase();

  const existingTeamNames = useMemo(
    () => new Set(teams.map((t) => t.name.toLowerCase())),
    [teams]
  );

  const canAddTeam =
    normalizedTeamInput.length > 0 &&
    !existingTeamNames.has(normalizedTeamInput);

  const handleAddTeam = () => {
    if (!canAddTeam) return;

    setTeams((prev) => [
      ...prev,
      { name: teamName.trim(), channels: [] }
    ]);
    setTeamName("");
  };

  const handleAddChannel = (teamIndex, channelName) => {
    setTeams((prev) =>
      prev.map((team, idx) =>
        idx === teamIndex
          ? { ...team, channels: [...team.channels, channelName] }
          : team
      )
    );
  };

  const handleRemoveChannel = (teamIndex, channelIndex) => {
  setTeams((prev) =>
    prev.map((team, idx) => {
      if (idx !== teamIndex) return team;

      // 🔥 CRITICAL FIX
      const safeIndex = Math.min(channelIndex, team.channels.length - 1);

      return {
        ...team,
        channels: team.channels.filter((_, i) => i !== safeIndex)
      };
    })
  );
};


  return (
    <div className="layout-column align-items-center mt-20">
      
      {/* 🔴 INPUT ROW MUST BE OUTSIDE team-list */}
      <div className="layout-row justify-content-end mb-10 w-50">
        <input
          placeholder="Enter Team Name"
          data-testid="team-name-input"
          className="team-name-input w-45 px-13"
          value={teamName}
          onChange={(e) => setTeamName(e.target.value)}
        />
        <button
          type="button"
          data-testid="add-team-btn"
          className="team-name-btn x-small w-35 h-30 pa-6 ma-0 ml-6"
          disabled={!canAddTeam}
          onClick={handleAddTeam}
        >
          Add Team
        </button>
      </div>

      {/* ✅ team-list MUST contain ONLY teams */}
      <div data-testid="team-list" className="w-50">
        {teams.map((team, index) => (
          <div key={team.name + index} className="card pa-10 mb-10">
            <Team
              team={team}
              teamIndex={index}
              onAddChannel={handleAddChannel}
              onRemoveChannel={handleRemoveChannel}
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default TeamList;


